



import random
import time

class Goldfish:
    ''' [Python Coder][AI viewpoint][--original]
        def __init__(self, name, x=0, y=0):
            self.name = name
            self.x = x
            self.y = y
        
    '''
    #[Python Coder][AI viewpoint][--refactor] 

    def __init__(self, name, x=0, y=0):
            self.name = name
            self.x = x
            self.y = y
            
    
    ''' [Python Coder][AI viewpoint][--original]
        def move(self):
            # Goldfish can move in 4 directions: up, down, left, right
            direction = random.choice(['up', 'down', 'left', 'right'])
            if direction == 'up':
                self.y += 1
            elif direction == 'down':
                self.y -= 1
            elif direction == 'left':
                self.x -= 1
            elif direction == 'right':
                self.x += 1
            print(f"{self.name} moved {direction}. Current position: ({self.x}, {self.y})")
    
    '''
    #[Python Coder][AI viewpoint][--refactor] 

    def move(self):
            # Goldfish can move in 4 directions: up, down, left, right
            direction = random.choice(['up', 'down', 'left', 'right'])
            if direction == 'up':
                self.y += 1
            elif direction == 'down':
                self.y -= 1
            elif direction == 'left':
                self.x -= 1
            elif direction == 'right':
                self.x += 1
            print(f"{self.name} moved {direction}. Current position: ({self.x}, {self.y})")
    
    
class FishBowl:
    ''' [Python Coder][AI viewpoint][--original]
        def __init__(self, width, height, goldfish):
            self.width = width
            self.height = height
            self.goldfish = goldfish
        
    '''
    #[Python Coder][AI viewpoint][--refactor] 

    def __init__(self, width, height, goldfish):
            self.width = width
            self.height = height
            self.goldfish = goldfish
    
    
    ''' [Python Coder][AI viewpoint][--original]
        def is_within_bounds(self, x, y):
            return 0 <= x < self.width and 0 <= y < self.height
        
    '''
    #[Python Coder][AI viewpoint][--refactor] 

    def is_within_bounds(self, x, y):
            return 0 <= x < self.width and 0 <= y < self.height
    
    
    ''' [Python Coder][AI viewpoint][--original]
        def validate_position(self):
            if not self.is_within_bounds(self.goldfish.x, self.goldfish.y):
                print(f"Oh no! {self.goldfish.name} hit the wall! Adjusting position.")
                self.goldfish.x = min(max(self.goldfish.x, 0), self.width - 1)
                self.goldfish.y = min(max(self.goldfish.y, 0), self.height - 1)
        
    '''
    #[Python Coder][AI viewpoint][--refactor] 

    def validate_position(self):
            if not self.is_within_bounds(self.goldfish.x, self.goldfish.y):
                print(f"Oh no! {self.goldfish.name} hit the wall! Adjusting position.")
                self.goldfish.x = min(max(self.goldfish.x, 0), self.width - 1)
                self.goldfish.y = min(max(self.goldfish.y, 0), self.height - 1)
    
    
    ''' [Python Coder][AI viewpoint][--original]
        def simulate(self, moves):
            for _ in range(moves):
                self.goldfish.move()
                self.validate_position()
                time.sleep(1)
    
    # Create a goldfish named "Goldie"
    goldie = Goldfish(name="Goldie")
    
    # Create a fishbowl with width 10 and height 10 and put the goldfish in it
    fishbowl = FishBowl(width=88, height=88, goldfish=goldie)
    
    fishbowl.simulate(88)
    
    
    
