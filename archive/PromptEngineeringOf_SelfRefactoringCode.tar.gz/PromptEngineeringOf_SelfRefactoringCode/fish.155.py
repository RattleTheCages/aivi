




import random
import time
import os

class Goldfish:
    def __init__(self, name, x=0, y=0):
        self.name = name
        self.x = x
        self.y = y
        # Assign a default fish symbol or based on the name
        self.fish_symbol = {'Goldie': 'g', 'Bubbles': 'b', 'Splash': 's', 'Fin': 'f', 'Dory': 'd', 'Nemo': 'n', 'Aqua': 'a', 'Coral': 'c', 'Pebbles': 'p', 'Marlin': 'm', 'Squirt': 'q'}.get(name, 'g')
        
    def move(self):
        # Goldfish can move in 4 directions: up, down, left, right
        direction = random.choice(['up', 'down', 'left', 'right'])
        if direction == 'up':
            self.y += 1
        elif direction == 'down':
            self.y -= 1
        elif direction == 'left':
            self.x -= 1
        elif direction == 'right':
            self.x += 1
        print(f"{self.name} moved {direction}. Current position: ({self.x}, {self.y})")

class Shark:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y
        self.shark_symbol = '🦈'  # Using a shark emoji as the symbol
    
    def move_towards_fish(self, fish):
        if self.x < fish.x:
            self.x += 2
        elif self.x > fish.x:
            self.x -= 2
        if self.y < fish.y:
            self.y += 2
        elif self.y > fish.y:
            self.y -= 2
        print(f"Shark moved towards {fish.name}. Current position: ({self.x}, {self.y})")

class FishBowl:
    def __init__(self, width, height, goldfish, shark):
        self.width = width
        self.height = height
        self.goldfish = goldfish
        self.shark = shark

    def is_within_bounds(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    def validate_position(self, fish):
        if not self.is_within_bounds(fish.x, fish.y):
            print(f"Oh no! {fish.name} hit the wall! Adjusting position.")
            fish.x = min(max(fish.x, 0), self.width - 1)
            fish.y = min(max(fish.y, 0), self.height - 1)

    def display(self):
        # Create a 2D array representing the fishbowl
        bowl = [[' ' for _ in range(self.width)] for _ in range(self.height)]
        # Place the goldfish in the bowl using their symbols
        for fish in self.goldfish:
            if self.is_within_bounds(fish.x, fish.y):
                bowl[fish.y][fish.x] = fish.fish_symbol
        # Place the shark in the bowl
        if self.is_within_bounds(self.shark.x, self.shark.y):
            bowl[self.shark.y][self.shark.x] = self.shark.shark_symbol
        # Construct the top and bottom borders with more of an oval shape
        top_border = ' ' + '_' * (self.width) + ' '
        bottom_border = ' ' + '‾' * (self.width) + ' '
        # Clear the screen
        os.system('cls' if os.name == 'nt' else 'clear')
        # Print the top border
        print(top_border)
        # Print the fishbowl with left and right rounded borders
        for i, row in enumerate(bowl):
            if i == 0 or i == self.height - 1:
                # Adding rounded corners at the top and bottom
                left_border = '('
                right_border = ')'
            else:
                left_border = '|'
                right_border = '|'
            print(f"{left_border}{''.join(row)}{right_border}")
        # Print the bottom border
        print(bottom_border)

    def simulate(self):
        while self.goldfish:
            for fish in self.goldfish[:]:
                fish.move()
                self.validate_position(fish)
                self.shark.move_towards_fish(fish)
                if self.shark.x == fish.x and self.shark.y == fish.y:
                    print(f"The shark caught {fish.name}! {fish.name} has been eliminated.")
                    self.goldfish.remove(fish)
            self.display()
            time.sleep(0.5)
        print("All the fish have been caught!")

# Create sixteen goldfish
goldie = Goldfish(name="Goldie", x=10, y=3)
bubbles = Goldfish(name="Bubbles", x=5, y=7)
splash = Goldfish(name="Splash", x=15, y=10)
fin = Goldfish(name="Fin", x=20, y=15)
dory = Goldfish(name="Dory", x=22, y=5)
nemo = Goldfish(name="Nemo", x=18, y=8)
aqua = Goldfish(name="Aqua", x=7, y=19)
coral = Goldfish(name="Coral", x=12, y=17)
pebbles = Goldfish(name="Pebbles", x=26, y=4)
marlin = Goldfish(name="Marlin", x=5, y=12)
squirt = Goldfish(name="Squirt", x=30, y=10)
guppy = Goldfish(name="Guppy", x=13, y=8)
flash = Goldfish(name="Flash", x=9, y=14)
shimmer = Goldfish(name="Shimmer", x=1, y=6)
sky = Goldfish(name="Sky", x=21, y=9)
blitz = Goldfish(name="Blitz", x=17, y=3)

# Create a shark
shark = Shark(x=0, y=0)

# Create a fishbowl with width 40 and height 20, add the goldfish and the shark
fishbowl = FishBowl(width=40, height=20, goldfish=[goldie, bubbles, splash, fin, dory, nemo, aqua, coral, pebbles, marlin, squirt, guppy, flash, shimmer, sky, blitz], shark=shark)

# Start the simulation
fishbowl.simulate()



