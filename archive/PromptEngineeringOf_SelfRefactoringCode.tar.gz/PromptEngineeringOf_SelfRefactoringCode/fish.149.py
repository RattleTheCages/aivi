




import random
import time
import os

class Goldfish:
    def __init__(self, name, x=0, y=0):
        self.name = name
        self.x = x
        self.y = y
        # Assign a default fish symbol or based on the name
        self.fish_symbol = {'Goldie': 'G', 'Bubbles': 'B', 'Splash': 'S', 'Fin': 'F'}.get(name, 'G')
        
    def move(self):
        # Goldfish can move in 4 directions: up, down, left, right
        direction = random.choice(['up', 'down', 'left', 'right'])
        if direction == 'up':
            self.y += 1
        elif direction == 'down':
            self.y -= 1
        elif direction == 'left':
            self.x -= 1
        elif direction == 'right':
            self.x += 1
        print(f"{self.name} moved {direction}. Current position: ({self.x}, {self.y})")

class FishBowl:
    def __init__(self, width, height, goldfish):
        self.width = width
        self.height = height
        self.goldfish = goldfish
        
    def is_within_bounds(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    def validate_position(self):
        for fish in self.goldfish:
            if not self.is_within_bounds(fish.x, fish.y):
                print(f"Oh no! {fish.name} hit the wall! Adjusting position.")
                fish.x = min(max(fish.x, 0), self.width - 1)
                fish.y = min(max(fish.y, 0), self.height - 1)

    def display(self):
        # Create a 2D array representing the fishbowl
        bowl = [[' ' for _ in range(self.width)] for _ in range(self.height)]
        # Place the goldfish in the bowl using their symbols
        for fish in self.goldfish:
            bowl[fish.y][fish.x] = fish.fish_symbol
        # Construct the top and bottom borders with more of an oval shape
        top_border = ' ' + '_' * (self.width) + ' '
        bottom_border = ' ' + '‾' * (self.width) + ' '
        # Clear the screen
        os.system('cls' if os.name == 'nt' else 'clear')
        # Print the top border
        print(top_border)
        # Print the fishbowl with left and right rounded borders
        for i, row in enumerate(bowl):
            if i == 0 or i == self.height - 1:
                # Adding rounded corners at the top and bottom
                left_border = '('
                right_border = ')'
            else:
                left_border = '|'
                right_border = '|'
            print(f"{left_border}{''.join(row)}{right_border}")
        # Print the bottom border
        print(bottom_border)

    def simulate(self, moves):
        for _ in range(moves):
            for fish in self.goldfish:
                fish.move()
            self.validate_position()
            self.display()
            time.sleep(0.5)

# Create four goldfish
goldie = Goldfish(name="Goldie", x=10, y=3)
bubbles = Goldfish(name="Bubbles", x=5, y=7)
splash = Goldfish(name="Splash", x=15, y=10)
fin = Goldfish(name="Fin", x=20, y=15)

# Create a fishbowl with width 40 and height 20 and put the goldfish in it
fishbowl = FishBowl(width=40, height=20, goldfish=[goldie, bubbles, splash, fin])
fishbowl.simulate(888)


