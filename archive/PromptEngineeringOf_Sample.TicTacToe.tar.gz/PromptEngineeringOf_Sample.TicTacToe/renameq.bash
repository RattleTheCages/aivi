#!/bin/bash

# Loop through all files in the current directory starting with 'quick'
for file in quick*; do
    # Check if the file exists to avoid errors
    if [[ -e "$file" ]]; then
        # Create the new filename by replacing 'quick' with 'TicTacToe'
        new_name="TicTacToe${file#quick}"
        
        # Rename the file
        mv -- "$file" "$new_name"
        
        # Print a message indicating the file is renamed
        echo "Renamed '$file' to '$new_name'"
    else
        echo "No files found starting with 'quick'"
    fi
done
