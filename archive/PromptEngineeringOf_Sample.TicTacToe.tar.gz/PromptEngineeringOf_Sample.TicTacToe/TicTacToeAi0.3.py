

Certainly! Below is a simple implementation of a two-player Tic-Tac-Toe game in Python.

```python
def print_board(board):
    for row in board:
        print("|".join(row))
        print("-" * 5)


def check_winner(board):
    # Check rows
    for row in board:
        if row[0] == row[1] == row[2] and row[0] != " ":
            return row[0]

    # Check columns
    for col in range(3):
        if board[0][col] == board[1][col] == board[2][col] and board[0][col] != " ":
            return board[0][col]

    # Check diagonals
    if board[0][0] == board[1][1] == board[2][2] and board[0][0] != " ":
        return board[0][0]
    if board[0][2] == board[1][1] == board[2][0] and board[0][2] != " ":
        return board[0][2]

    return None


def check_tie(board):
    for row in board:
        if " " in row:
            return False
    return True


def get_move(player):
    while True:
        try:
            move = int(input(f"Player {player}, enter your move (1-9): ")) - 1
            if move < 0 or move > 8:
                print("Invalid move. Please try again.")
            else:
                return move
        except ValueError:
            print("Invalid input. Please enter a number between 1 and 9.")


def main():
    board = [[" " for _ in range(3)] for _ in range(3)]
    current_player = "X"

    while True:
        print_board(board)
        move = get_move(current_player)

        row, col = divmod(move, 3)

        if board[row][col] != " ":
            print("The cell is already occupied. Please try again.")
            continue

        board[row][col] = current_player

        winner = check_winner(board)
        if winner:
            print_board(board)
            print(f"Player {winner} wins!")
            break
        elif check_tie(board):
            print_board(board)
            print("It's a tie!")
            break

        current_player = "O" if current_player == "X" else "X"


if __name__ == "__main__":
    main()
```

### How to Play:
1. Run the script.
2. Players take turns entering their move as a number between 1 and 9 where:
    ```
    1 | 2 | 3
    ---------
    4 | 5 | 6
    ---------
    7 | 8 | 9
    ```
3. The program will check for a winner or a tie after every move.
4. The game will prompt for a valid input if an invalid move is entered (either out of bounds or an already occupied cell).

Enjoy playing!
Sure! To change this game to allow one player to play against the computer, we need to add a simple AI for the computer's move. Here, I'll use a basic strategy where the computer will choose a random move from available spaces.

First, we'll add a function to get the computer's move. Then, we'll modify the main game loop to handle the computer as "O" and the player as "X".

Below is the modified code:
```python
import random

def print_board(board):
    for row in board:
        print("|".join(row))
        print("-" * 5)

def check_winner(board):
    # Check rows
    for row in board:
        if row[0] == row[1] == row[2] and row[0] != " ":
            return row[0]
    # Check columns
    for col in range(3):
        if board[0][col] == board[1][col] == board[2][col] and board[0][col] != " ":
            return board[0][col]
    # Check diagonals
    if board[0][0] == board[1][1] == board[2][2] and board[0][0] != " ":
        return board[0][0]
    if board[0][2] == board[1][1] == board[2][0] and board[0][2] != " ":
        return board[0][2]
    return None

def check_tie(board):
    for row in board:
        if " " in row:
            return False
    return True

def get_player_move():
    while True:
        try:
            move = int(input("Player X, enter your move (1-9): ")) - 1
            if move < 0 or move > 8:
                print("Invalid move. Please try again.")
            else:
                return move
        except ValueError:
            print("Invalid input. Please enter a number between 1 and 9.")

def get_computer_move(board):
    available_moves = [(r, c) for r in range(3) for c in range(3) if board[r][c] == " "]
    return random.choice(available_moves)

def main():
    board = [[" " for _ in range(3)] for _ in range(3)]
    current_player = "X"
    while True:
        print_board(board)
        if current_player == "X":
            move = get_player_move()
            row, col = divmod(move, 3)
        else:
            print("Computer's turn...")
            row, col = get_computer_move(board)

        if board[row][col] != " ":
            print("The cell is already occupied. Please try again.")
            continue
        
        board[row][col] = current_player
        winner = check_winner(board)
        if winner:
            print_board(board)
            print(f"Player {winner} wins!")
            break
        elif check_tie(board):
            print_board(board)
            print("It's a tie!")
            break

        current_player = "O" if current_player == "X" else "X"

if __name__ == "__main__":
    main()
```

### Modifications:
1. **`get_player_move`**: Function to get the move from the human player (Player X).
2. **`get_computer_move`**: Function to determine the computer's move by selecting a random available spot.
3. **In the main loop**:
   - Check `current_player` to decide if it's the player's or computer's turn.
   - If it's the player's turn, get the move from `get_player_move`.
   - If it's the computer's turn, get the move from `get_computer_move`.

This implementation allows a single player to play against a basic AI that randomly selects its moves. You can further improve the AI by implementing more advanced strategies if desired.
Absolutely! Here, I will improve the Tic-Tac-Toe game by adding a more advanced strategy for the computer player. This strategy will include an algorithm to determine the best move based on the current state of the board. To keep it simple, we will use the Minimax algorithm.

Here's the modified code to implement a one-player game against a strategic computer:

```python
def print_board(board):
    for row in board:
        print("|".join(row))
        print("-" * 5)

def check_winner(board):
    # Check rows
    for row in board:
        if row[0] == row[1] == row[2] and row[0] != " ":
            return row[0]
    # Check columns
    for col in range(3):
        if board[0][col] == board[1][col] == board[2][col] and board[0][col] != " ":
            return board[0][col]
    # Check diagonals
    if board[0][0] == board[1][1] == board[2][2] and board[0][0] != " ":
        return board[0][0]
    if board[0][2] == board[1][1] == board[2][0] and board[0][2] != " ":
        return board[0][2]
    return None

def check_tie(board):
    for row in board:
        if " " in row:
            return False
    return True

def get_player_move():
    while True:
        try:
            move = int(input("Player X, enter your move (1-9): ")) - 1
            if move < 0 or move > 8:
                print("Invalid move. Please try again.")
            else:
                return move
        except ValueError:
            print("Invalid input. Please enter a number between 1 and 9.")

def minimax(board, depth, is_maximizing):
    winner = check_winner(board)
    if winner == "O":
        return 1
    elif winner == "X":
        return -1
    elif check_tie(board):
        return 0

    if is_maximizing:
        best_score = -float('inf')
        for r in range(3):
            for c in range(3):
                if board[r][c] == " ":
                    board[r][c] = "O"
                    score = minimax(board, depth + 1, False)
                    board[r][c] = " "
                    best_score = max(score, best_score)
        return best_score
    else:
        best_score = float('inf')
        for r in range(3):
            for c in range(3):
                if board[r][c] == " ":
                    board[r][c] = "X"
                    score = minimax(board, depth + 1, True)
                    board[r][c] = " "
                    best_score = min(score, best_score)
        return best_score

def get_computer_move(board):
    best_score = -float('inf')
    best_move = None
    for r in range(3):
        for c in range(3):
            if board[r][c] == " ":
                board[r][c] = "O"
                score = minimax(board, 0, False)
                board[r][c] = " "
                if score > best_score:
                    best_score = score
                    best_move = (r, c)
    return best_move

def main():
    board = [[" " for _ in range(3)] for _ in range(3)]
    current_player = "X"
    while True:
        print_board(board)
        if current_player == "X":
            move = get_player_move()
            row, col = divmod(move, 3)
        else:
            print("Computer's turn...")
            row, col = get_computer_move(board)
        if board[row][col] != " ":
            print("The cell is already occupied. Please try again.")
            continue
        board[row][col] = current_player
        winner = check_winner(board)
        if winner:
            print_board(board)
            print(f"Player {winner} wins!")
            break
        elif check_tie(board):
            print_board(board)
            print("It's a tie!")
            break
        current_player = "O" if current_player == "X" else "X"

if __name__ == "__main__":
    main()
```

### Modifications:
1. **Minimax Algorithm**:
    - `minimax`: Recursively evaluates the game board using the minimax algorithm to find the best move.
    - `get_computer_move`: Uses the minimax algorithm to select the best available move for the computer.

2. **Board Representation and Moves**:
    - Players input moves as numbers (1-9), and the board is represented as a 3x3 list of lists.
    - `divmod` is used to convert a move number to a row and column index.

This implementation allows the computer to make optimal moves, providing a challenging opponent for the player. The Minimax algorithm ensures that the computer plays perfectly, and it will either win or force a draw if both players play optimally. Enjoy the game!
To adapt the existing Tic-Tac-Toe game to have both players as computers playing in an endless loop, we can use the modified functions and adapt the main loop accordingly. Specifically, we need to make sure to cycle through games, reset the board, and add a quit condition to break the endless loop.

Here's the updated Python code:

```python
import random

def print_board(board):
    for row in board:
        print("|".join(row))
        print("-" * 5)

def check_winner(board):
    for row in board:
        if row[0] == row[1] == row[2] and row[0] != " ":
            return row[0]
    for col in range(3):
        if board[0][col] == board[1][col] == board[2][col] and board[0][col] != " ":
            return board[0][col]
    if board[0][0] == board[1][1] == board[2][2] and board[0][0] != " ":
        return board[0][0]
    if board[0][2] == board[1][1] == board[2][0] and board[0][2] != " ":
        return board[0][2]
    return None

def check_tie(board):
    for row in board:
        if " " in row:
            return False
    return True

def minimax(board, depth, is_maximizing):
    winner = check_winner(board)
    if winner == "O":
        return 1
    elif winner == "X":
        return -1
    elif check_tie(board):
        return 0

    if is_maximizing:
        best_score = -float('inf')
        for r in range(3):
            for c in range(3):
                if board[r][c] == " ":
                    board[r][c] = "O"
                    score = minimax(board, depth + 1, False)
                    board[r][c] = " "
                    best_score = max(score, best_score)
        return best_score
    else:
        best_score = float('inf')
        for r in range(3):
            for c in range(3):
                if board[r][c] == " ":
                    board[r][c] = "X"
                    score = minimax(board, depth + 1, True)
                    board[r][c] = " "
                    best_score = min(score, best_score)
        return best_score

def get_computer_move(board, player):
    best_score = -float('inf') if player == 'O' else float('inf')
    best_move = None
    for r in range(3):
        for c in range(3):
            if board[r][c] == " ":
                board[r][c] = player
                if player == "O":
                    score = minimax(board, 0, False)
                else:
                    score = minimax(board, 0, True)
                board[r][c] = " "
                if (player == "O" and score > best_score) or (player == "X" and score < best_score):
                    best_score = score
                    best_move = (r, c)
    return best_move

def main():
    while True:
        board = [[" " for _ in range(3)] for _ in range(3)]
        current_player = "X"
        while True:
            print_board(board)
            if current_player == "X":
                row, col = get_computer_move(board, "X")
            else:
                row, col = get_computer_move(board, "O")
            
            board[row][col] = current_player
            winner = check_winner(board)
            if winner:
                print_board(board)
                print(f"Player {winner} wins!")
                break
            elif check_tie(board):
                print_board(board)
                print("It's a tie!")
                break
            current_player = "O" if current_player == "X" else "X"

        # Uncomment below lines if you want to add a break in the loop
        # reply = input("Play another game? (yes to continue/no to stop): ")
        # if reply.lower() != 'yes':
        #     break

if __name__ == "__main__":
    main()
```

### Key Changes:
1. **`get_computer_move` Function**:
    - This function was refactored to take the player (`"X"` or `"O"`) as an input and determine the best move using the Minimax algorithm tailored for that player's perspective.

2. **Endless Loop Setup**:
    - The `main` loop is adjusted to reset the board and continuously play the game.
  
3. **Optional User Input to Exit**:
    - You can enable the break in the loop by uncommenting the lines at the end of the `main` loop if you want to add an option to stop the endless game cycle. This will prompt the user to decide whether to continue after each game.

This version of the game continuously pits two computer opponents against each other using the Minimax algorithm to play optimally. Enjoy watching the battles!
