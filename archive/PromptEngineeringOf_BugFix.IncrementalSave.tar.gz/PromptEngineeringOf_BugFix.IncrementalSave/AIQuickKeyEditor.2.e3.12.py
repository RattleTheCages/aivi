# AIQuickKeyEditor -- The editor that wrote itself.
# AIQuickKeyEditor is the prototype editor for the Aivi editor.
# This editor is a fully functioning editor that offers AI assistance.
# The top window is where you enter text and edit it; the bottom window is the AI command window, where you can enter requests for AI assistance.
# Use ctrl-v to choose the type of AI assistance you need, such as grammar and spelling corrections, or Python coding.
# In freestyle mode, one can enter any question or content, similar to a well-known subscription AI interface.
# This work is copyright. All rights reserved.
import os
import json
import argparse
import curses
import signal
from openai import OpenAI
parser = argparse.ArgumentParser()
parser.add_argument('file', nargs='?', default=None)
args = parser.parse_args()
client = OpenAI(api_key=os.environ.get("CUSTOM_ENV_NAME"))
class CogQuery:
    @classmethod
    def get_unique_request_counter(cls, file_base_name):
        while os.path.exists(f'{file_base_name}_{cls.request_counter}.txt'):
            cls.update_request_counter()
        return cls.request_counter
    request_counter = 0
    def __init__(self, role, content):
        self.role = role
        self.content = content
    @classmethod
    def update_request_counter(cls):
        cls.request_counter += 1
        return cls.request_counter
    @classmethod
   
