def indent_lines(input_file, output_file):
    try:
        with open(input_file, 'r') as infile:
            lines = infile.readlines()

        with open(output_file, 'w') as outfile:
            for line in lines:
                outfile.write('    ' + line)  # Prefix each line with four spaces

        print(f"Indented lines have been written to {output_file}.")
    except FileNotFoundError:
        print(f"The file {input_file} does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    input_file = input("Enter the path to the input text file: ")
    output_file = input("Enter the path to the output text file: ")
    indent_lines(input_file, output_file)
