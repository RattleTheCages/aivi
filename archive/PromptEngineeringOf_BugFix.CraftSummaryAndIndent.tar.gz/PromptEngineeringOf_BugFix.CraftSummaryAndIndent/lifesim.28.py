

import os
import time

class GameOfLife:
    def __init__(self, rows, cols, initial_state=None):
        self.rows = rows
        self.cols = cols
        self.grid = self.initialize_grid(initial_state)

    def initialize_grid(self, initial_state):
        if initial_state:
            return initial_state
        else:
            # Create a grid with all cells dead
            return [[0 for _ in range(self.cols)] for _ in range(self.rows)]

    def display_grid(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        for row in self.grid:
            print(''.join(['█' if cell else ' ' for cell in row]))
        print("\n")

    def count_alive_neighbors(self, x, y):
        directions = [(-1, -1), (-1, 0), (-1, 1), 
                      (0, -1),          (0, 1), 
                      (1, -1), (1, 0), (1, 1)]
        alive_neighbors = 0
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.rows and 0 <= ny < self.cols:
                alive_neighbors += self.grid[nx][ny]
        return alive_neighbors

    def update_cell(self, x, y):
        alive_neighbors = self.count_alive_neighbors(x, y)
        if self.grid[x][y] == 1:
            # Any live cell with two or three live neighbors survives.
            return 1 if alive_neighbors in [2, 3] else 0
        else:
            # Any dead cell with three live neighbors becomes a live cell
            return 1 if alive_neighbors == 3 else 0

    def update_grid(self):
        new_grid = [[self.update_cell(x, y) for y in range(self.cols)] for x in range(self.rows)]
        self.grid = new_grid

    def run(self, delay=0.1):
        while True:
            self.display_grid()
            self.update_grid()
            time.sleep(delay)

def main():
    initial_state = [
        [0, 0, 0, 0, 0],
        [0, 1, 1, 1, 0],
        [0, 1, 0, 1, 0],
        [0, 1, 1, 1, 0],
        [0, 0, 0, 0, 0]
    ]
    game = GameOfLife(rows=5, cols=5, initial_state=initial_state)
    game.run()

if __name__ == "__main__":
    main()




