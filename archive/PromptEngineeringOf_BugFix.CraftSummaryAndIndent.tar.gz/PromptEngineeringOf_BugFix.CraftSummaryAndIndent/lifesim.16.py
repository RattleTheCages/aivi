





class GameOfLife:
    def __init__(self, rows, cols):
            self.rows = rows
            self.cols = cols
            self.board = [[0 for _ in range(cols)] for _ in range(rows)]
        
    
    def set_live_cells(self, live_cells):
            for (r, c) in live_cells:
                if 0 <= r < self.rows and 0 <= c < self.cols:
                    self.board[r][c] = 1
        
    
    def print_board(self):
            for row in self.board:
                print(' '.join('█' if cell else ' ' for cell in row))
            print()
        
    
    def get_neighbor_count(self, row, col):
            directions = [(-1, -1), (-1, 0), (-1, 1),
                          ( 0, -1),         ( 0, 1),
                          ( 1, -1), ( 1, 0), ( 1, 1)]
            count = 0
            for dr, dc in directions:
                r, c = row + dr, col + dc
                if 0 <= r < self.rows and 0 <= c < self.cols:
                    count += self.board[r][c]
            return count
        
    
    def update_board(self):
            new_board = [[0 for _ in range(self.cols)] for _ in range(self.rows)]
            for r in range(self.rows):
                for c in range(self.cols):
                    live_neighbors = self.get_neighbor_count(r, c)
                    if self.board[r][c] == 1:
                        if live_neighbors < 2 or live_neighbors > 3:
                            new_board[r][c] = 0
                        else:
                            new_board[r][c] = 1
                    else:
                        if live_neighbors == 3:
                            new_board[r][c] = 1
            self.board = new_board
        
    
def run(self, iterations):
            for _ in range(iterations):
                os.system('cls' if os.name == 'nt' else 'clear')
                self.print_board()
                self.update_board()
                time.sleep(0.5)  # Pause for 0.5 seconds
    
    # Set up initial configuration and run the Game of Life
if __name__ == "__main__":
        # Initialize the game with a 10x10 board
    game = GameOfLife(10, 10)
        # Set some initial live cells
    initial_live_cells = [(1,2), (2,3), (3,1), (3,2), (3,3)]
    game.set_live_cells(initial_live_cells)
        # Run the game for 88 iterations
    game.run(88)
    
