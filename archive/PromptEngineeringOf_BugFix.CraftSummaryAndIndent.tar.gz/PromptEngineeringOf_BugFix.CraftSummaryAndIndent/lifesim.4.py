
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

class GameOfLife:
    def __init__(self, size, initial_state=None):
        self.size = size
        if initial_state is None:
            self.grid = np.zeros((size, size), dtype=int)
        else:
            self.grid = initial_state

    def step(self):
        new_grid = self.grid.copy()
        for i in range(self.size):
            for j in range(self.size):
                # Count the number of live neighbors
                live_neighbors = np.sum(self.grid[max(0, i-1):min(self.size, i+2), max(0, j-1):min(self.size, j+2)]) - self.grid[i, j]
                
                # Apply the rules of the Game of Life
                if self.grid[i, j] == 1:
                    if live_neighbors < 2 or live_neighbors > 3:
                        new_grid[i, j] = 0
                else:
                    if live_neighbors == 3:
                        new_grid[i, j] = 1
        
        self.grid = new_grid

    def animate(self, interval=200, frames=50):
        fig, ax = plt.subplots()
        img = ax.imshow(self.grid, interpolation='nearest')

        def update(frame):
            self.step()
            img.set_data(self.grid)
            return img,

        ani = animation.FuncAnimation(fig, update, frames=frames, interval=interval, blit=True)
        plt.show()

if __name__ == "__main__":
    size = 50  # Define the size of the grid

    # Optional: Define an initial state (otherwise, it starts with a grid of zeros)
    initial_state = np.random.choice([0, 1], size * size, p=[0.8, 0.2]).reshape(size, size)

    game = GameOfLife(size, initial_state)
    game.animate()





