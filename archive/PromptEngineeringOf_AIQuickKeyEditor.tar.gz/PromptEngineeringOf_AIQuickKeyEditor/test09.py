In order to address your request, we need to modify the `handle_backslash` method to ensure that the JSON string includes the Cognatlities of the current name under the personal choice. Here is the complete and corrected version of the `handle_backslash` method inside the `AIQuickEditor` class:

```python
def handle_backslash(self):  # Backslash ('\')
    self.context.reset()

    for attribute in self.windows[1]["text"]:
        if attribute.strip():    # Only add non-empty lines
            self.context.add_cogtext("system", attribute)

    userlines = "\n".join(self.windows[0]["text"])
    self.context.add_usermsg(userlines)

    # Adding the Cognatlities of the current personalchoice to the context
    chosen_attributes = self.cognalities.get_attributes()
    for attribute in chosen_attributes:
        self.context.add_cogtext("system", attribute)

    self.context.save_cogtext('before_context.json')
    self.status = "ai   "
    self.display()

    # Debug, write the context before the AI reply.
    sys.stdout.write(json.dumps({
        "personalchoice": self.personalchoice,
        "context": self.context.get_cogtext_by_name(self.personalchoice)
    }, indent=2))

    exit()

    completion = client.chat.completions.create(
        model=self.context.get_model(),
        max_tokens=self.context.get_maxtokens(),
        messages=self.context.get_cogtext_by_name(self.personalchoice)
    )
    self.context.add_cogtext("assistant", completion.choices[0].message.content)
    self.context.save_cogtext('ai_context.json')

    self.oldtext = self.windows[0]["text"]
    self.windows[0]["text"] = completion.choices[0].message.content.split('\n')
    self.windows[0]["line_num"] = len(self.windows[0]["text"]) - 1
    self.windows[0]["col_num"] = len(self.windows[0]["text"][self.windows[0]["line_num"]])
    self.mode = "reply"
```

### Explanation:
1. **Resetting the Context**: `self.context.reset()` clears any previous states.
2. **Adding Non-Empty Lines from Second Window**: Lines from the second window are added as system messages.
3. **Combining User Lines from First Window**: All user lines from the first window are combined and added to the user messages.
4. **Adding Current Cognatlities to Context**: The attributes of the current `personalchoice` are fetched and added as system messages to provide context.
5. **Saving and Displaying Context**: Save the current state of the context to a JSON file (`before_context.json`) and debug print it.
6. **Skipping the Exit Step in Production**: The `exit()` statement is for debugging. It should be removed or commented out in production.
7. **Making API Call**: A completion API call is made to OpenAI with the constructed context, and the reply is handled and displayed appropriately.

This ensures that the JSON string contains the context along with the attributes of the current personal choice, encapsulated under `personalchoice`.
