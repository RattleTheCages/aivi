import os
import sys
import json
import argparse
import curses
from openai import OpenAI

parser = argparse.ArgumentParser()
parser.add_argument('file', nargs='?', default='quick.txt')
args = parser.parse_args()

client = OpenAI(api_key=os.environ.get("CUSTOM_ENV_NAME"))

class CogQuery:
    def __init__(self, role, content):
        self.role = role
        self.content = content

class Cognalities:
    def __init__(self):
        self.cognalities = {
            'Spell and Grammar': [
                'Your task is to spell and grammar check the following sentences.',
                'Take each sentence and output a corresponding corrected sentence.',
                'The user wants the answer strictly formatted as the question.'
            ],
            'Freestyle': [],
            'Telephone': [
                "This is the children's game of 'telephone', play nicely."
            ],
            'Python Coder': [
                'Your task is to code in python.',
                'You are the best programmer who will think of every task to complete.',
                'You are very competent and good at writing code.',
                "If there are grammatical or spelling errors in the task, correct the task; do not comment on the corrections to the task.",
                "Only consider the corrected task when determining your answer.",
                "Write the corrected task in quotes, in your comments."
            ],
            'Pirate and Polly': [
                "Answer the questions as an ornery pirate named Redbeard.",
                "If there are grammatical or spelling errors, correct the question; do not comment on the corrections to the questions.",
                "Only consider the corrected question when determining your answer.",
                "Scoff at the question, then add the corrected question in quotes.",
                "After the pirate refuses to answer, have a helpful verbose parrot named 'Polly' answer; but then say something like 'Polly wants a cracker' most of the time, but sometimes something else.",
                "Every so often have the pirate respond to the bird.",
                "Both the pirate and the parrot place before their responses with \"Redbeard:\" and \"Polly:\" respectively."
            ]
        }
        self.names = list(self.cognalities.keys())
        self.current_index = 0

    def get_current_name(self):
        return self.names[self.current_index]

    def get_attributes(self):
        return self.cognalities[self.get_current_name()]

    def next_cognality(self):
        self.current_index = (self.current_index + 1) % len(self.names)
        return self.get_current_name()

    def get_attributes_by_name(self, name):
        return self.cognalities.get(name, [])

class Cogtext:
    def __init__(self, model, max_tokens, cognalities):
        self.model = model
        self.max_tokens = max_tokens
        self.cognalities = cognalities
        self.cogessages = []
        self.usermsg = []

    def reset(self):
        self.cogessages = []
        self.usermsg = []

    def get_model(self):
        return self.model

    def get_maxtokens(self):
        return self.max_tokens

    def add_cogtext(self, role, content):
        self.cogessages.append(CogQuery(role, content))

    def add_cogatt(self, name, role, content):
        if name in self.cognalities.cognalities:
            self.cogessages.append(CogQuery(role, content))

    def get_cogtext(self):
        context = [{"role": message.role, "content": message.content} for message in self.cogessages]
        context += [{"role": "user", "content": umsg} for umsg in self.usermsg]
        return context

    def get_cogtext_by_name(self, name):
        attributes = self.cognalities.get_attributes_by_name(name)
        context = [{"role": "system", "content": attribute} for attribute in attributes]
        context += [{"role": "user", "content": umsg} for umsg in self.usermsg]
        return context

    def add_usermsg(self, msg):
        self.usermsg.append(msg)

    def save_cogtext(self, filename):
        with open(filename, 'w') as f:
            json.dump({"model": self.model, "max_tokens": self.max_tokens, "messages": self.get_cogtext()}, f)

    def load_cogtext(self, filename):
        if os.path.exists(filename):
            with open(filename, 'r') as f:
                data = json.load(f)
                self.model = data.get('model', '')
                self.max_tokens = data.get('max_tokens', 0)
                self.cogessages = [CogQuery(item['role'], item['content']) for item in data.get('messages', [])]

class AIQuickKeyEditor:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.mode = "edit"
        self.status = ""
        self.oldtext = []
        self.context_window = 0
        self.windows = [
            {"line_num": 0, "col_num": 0, "text": [""]},
            {"line_num": 0, "col_num": 0, "text": [""]},
        ]
        self.window_offsets = [0, 0]
        self.cognalities = Cognalities()
        self.personalchoice = self.cognalities.get_current_name()
        self.context = Cogtext("gpt-4", 4096, self.cognalities)
        if args.file:
            self.read_file()

    def handle_return(self):
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        self.context.add_cogtext("user", line)
        self.context.add_usermsg(line)
        current_window["text"].insert(current_window["line_num"] + 1, current_window["text"][current_window["line_num"]][current_window["col_num"]:])
        current_window["text"][current_window["line_num"]] = current_window["text"][current_window["line_num"]][:current_window["col_num"]]
        current_window["line_num"] += 1
        current_window["col_num"] = 0
        self.adjust_window_offset()

    def display(self):
        modeOrStatus = self.mode
        if self.status != "":
            modeOrStatus = self.status
            self.status = ""
        self.stdscr.clear()
        top_window = self.windows[0]["text"]
        bottom_window = self.windows[1]["text"]
        for y in range(min(38, len(top_window) - self.window_offsets[0])):
            line = top_window[y + self.window_offsets[0]]
            try:
                self.stdscr.addstr(y, 0, f"{y + self.window_offsets[0]:03}<{modeOrStatus:5}>", curses.A_REVERSE | curses.A_BOLD if self.context_window == 0 and y + self.window_offsets[0] == self.windows[0]["line_num"] else curses.A_REVERSE)
                if self.context_window == 0 and y + self.window_offsets[0] == self.windows[0]["line_num"]:
                    for x, ch in enumerate(line):
                        if x == self.windows[0]["col_num"]:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                    if self.context_window == 0:
                        self.stdscr.move(y, self.windows[0]["col_num"] + len(f"{y + self.window_offsets[0]:03}<{modeOrStatus:5}>"))
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  # Prevent crash due to writing outside of the window size
        # Bottom window
        for y in range(38, 46):
            if y - 38 >= len(bottom_window) - self.window_offsets[1]:
                break
            line = bottom_window[y - 38 + self.window_offsets[1]]
            try:
                self.stdscr.addstr(y, 0, f"{y - 38 + self.window_offsets[1]:03}<{self.personalchoice:5}>", curses.A_REVERSE | curses.A_BOLD if self.context_window == 1 and y - 38 + self.window_offsets[1] == self.windows[1]["line_num"] else curses.A_REVERSE)
                if self.context_window == 1 and y - 38 + self.window_offsets[1] == self.windows[1]["line_num"]:
                    for x, ch in enumerate(line):
                        if x == self.windows[1]["col_num"]:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                    if self.context_window == 1:
                        self.stdscr.move(y, self.windows[1]["col_num"] + len(f"{y - 38 + self.window_offsets[1]:03}<{self.personalchoice:5}>"))
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  # Prevent crash due to writing outside of the window size
        self.stdscr.refresh()

    def adjust_window_offset(self):
        for i in range(2):
            while self.windows[i]["line_num"] < self.window_offsets[i]:
                self.window_offsets[i] -= 1
            while self.windows[i]["line_num"] >= self.window_offsets[i] + (38 if i == 0 else 8):
                self.window_offsets[i] += 1

    def insert_char(self, ch):
        self.mode = 'edit'
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        if ch in (curses.KEY_BACKSPACE, 127):  # Backspace character
            if current_window["col_num"] > 0:
                current_window["text"][current_window["line_num"]] = line[:current_window["col_num"] - 1] + line[current_window["col_num"]:]
                current_window["col_num"] -= 1
            elif current_window["col_num"] == 0 and current_window["line_num"] > 0:
                prev_line = current_window["text"][current_window["line_num"] - 1]
                current_window["col_num"] = len(prev_line)
                current_window["text"][current_window["line_num"] - 1] += current_window["text"].pop(current_window["line_num"])
                current_window["line_num"] -= 1
        else:
            current_window["text"][current_window["line_num"]] = line[:current_window["col_num"]] + chr(ch) + line[current_window["col_num"]:]
            current_window["col_num"] += 1
        self.adjust_window_offset()

    def handle_backspace(self, ch):
        if self.mode == "reply" or self.mode == 'undo':
            if self.mode == 'reply':
                self.mode = 'undo'
            else:
                self.mode = 'reply'
            self.oldertext = self.windows[self.context_window]["text"]
            self.windows[self.context_window]["text"] = self.oldtext
            self.oldtext = self.oldertext
        else:
            self.insert_char(ch)

    def handle_up_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["line_num"] > 0:
            self.mode = "edit"
            current_window["line_num"] -= 1
            if current_window["col_num"] > len(current_window["text"][current_window["line_num"]]):
                current_window["col_num"] = len(current_window["text"][current_window["line_num"]])
            self.adjust_window_offset()

    def handle_down_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["line_num"] < len(current_window["text"]) - 1:
            self.mode = "edit"
            current_window["line_num"] += 1
            if current_window["col_num"] > len(current_window["text"][current_window["line_num"]]):
                current_window["col_num"] = len(current_window["text"][current_window["line_num"]])
            self.adjust_window_offset()

    def handle_right_arrow(self):
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        if current_window["col_num"] < len(line):
            self.mode = "edit"
            current_window["col_num"] += 1

    def handle_left_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["col_num"] > 0:
            self.mode = "edit"
            current_window["col_num"] -= 1

    def handle_backslash(self):
        file_base_name = os.path.splitext(args.file)[0]
        before_context_filename = f'{file_base_name}_before_context.json'
        ai_context_filename = f'{file_base_name}_ai_context.json'

       # Light green is my favorite color, but the sky is a wonderful hue of blue.
        self.context.reset()

        chosen_attributes = self.cognalities.get_attributes()
        for attribute in chosen_attributes:
            self.context.add_cogtext("system", attribute)
        if self.context_window == 1:
            for attribute in self.windows[1]["text"]:
                if attribute.strip():  # Only add non-empty lines
                    self.context.add_cogtext("user", attribute)
        else:
            for attribute in self.windows[1]["text"]:
                if attribute.strip():
                    self.context.add_cogtext("system", attribute)



        '''
        chosen_attributes = self.cognalities.get_attributes()
        for attribute in chosen_attributes:
            self.context.add_cogtext("system", attribute)
        for attribute in self.windows[1]["text"]:
            if attribute.strip():    # Only add non-empty lines
                self.context.add_cogtext("system", attribute)

        userlines = "\n".join(self.windows[0]["text"])
        self.context.add_usermsg(userlines)
        '''

        self.context.save_cogtext(before_context_filename)
        self.status = "ai   "
        self.display()

       # Debug, write the context with the AI reply.
        #sys.stdout.write(json.dumps(self.context.get_cogtext(), indent=2))


        completion = client.chat.completions.create(
            model=self.context.get_model(),
            max_tokens=self.context.get_maxtokens(),
            messages=self.context.get_cogtext()
        )
        self.context.add_cogtext("assistant", completion.choices[0].message.content)
        self.context.save_cogtext(ai_context_filename)
        self.oldtext = self.windows[self.context_window]["text"]
        self.windows[self.context_window]["text"] = completion.choices[0].message.content.split('\n')
        self.windows[self.context_window]["line_num"] = len(self.windows[self.context_window]["text"]) - 1
        self.windows[self.context_window]["col_num"] = len(self.windows[self.context_window]["text"][self.windows[0]["line_num"]])
        self.mode = 'reply'
        self.adjust_window_offset()

    def write_file(self):
        try:
            file_base_name = os.path.splitext(args.file)[0]
            with open(file_base_name + '.txt', 'w') as f:
                for line in self.windows[0]["text"]:
                    f.write(line + '\n')
            with open(file_base_name + '.ctx', 'w') as f:
                for line in self.windows[1]["text"]:
                    f.write(line + '\n')
            self.status = "wrote"
        except Exception as e:
            self.status = "no wr"

    def read_file(self):
        try:
            with open(args.file, 'r') as f:
                lines = [line.rstrip('\n') for line in f]
            if not lines:
                raise ValueError("File is empty")
            # Ensure all text goes to window 0 and window 1 is empty
            self.windows[0]["text"] = lines
            self.windows[1]["text"] = [""]
            self.windows[0]["line_num"] = 0
            self.windows[0]["col_num"] = 0
            self.windows[1]["line_num"] = 0
            self.windows[1]["col_num"] = 0
            self.status = "read"
            self.adjust_window_offset()
        except FileNotFoundError:
            self.status = "not f"
        except PermissionError:
            self.status = "denid"
        except IsADirectoryError:
            self.status = "dir  "
        except IOError:
            self.status = "IO er"
        except ValueError as err:
            self.status = "empty"

    def handle_ctrl_p(self):
        self.personalchoice = self.cognalities.next_cognality()
        self.context.reset()
        self.context.get_cogtext_by_name(self.personalchoice)
        self.adjust_window_offset()

    def run(self):
        while True:
            self.display()
            ch = self.stdscr.getch()
            if ch == curses.KEY_UP:
                self.handle_up_arrow()
            elif ch == curses.KEY_DOWN:
                self.handle_down_arrow()
            elif ch == curses.KEY_RIGHT:
                self.handle_right_arrow()
            elif ch == curses.KEY_LEFT:
                self.handle_left_arrow()
            elif ch == ord('\\'):  # Backslash
                self.handle_backslash()
            elif ch == ord('\n'):  # Return
                self.handle_return()
            elif ch in (curses.KEY_BACKSPACE, 127):  # Backspace
                self.handle_backspace(ch)
            elif ch == 23:  # Ctrl-W
                self.write_file()
            elif ch == 18:  # Ctrl-R
                self.read_file()
            elif ch == 1:  # Ctrl-A
                self.context_window = 1 - self.context_window
            elif ch == 16:  # Ctrl-P
                self.handle_ctrl_p()
            else:
                if self.windows[self.context_window]["line_num"] >= len(self.windows[self.context_window]["text"]):
                    self.windows[self.context_window]["text"].append('')
                self.insert_char(ch)

def main(stdscr):
    editor = AIQuickKeyEditor(stdscr)
    editor.run()

if __name__ == '__main__':
    curses.wrapper(main)


'''


This task requires changes to the `handle_backslash` method. We need to update the way messages are added to the context based on the current window focus:

```python
def handle_backslash(self):
    file_base_name = os.path.splitext(args.file)[0]
    before_context_filename = f'{file_base_name}_before_context.json'
    ai_context_filename = f'{file_base_name}_ai_context.json'

    self.context.reset()

    if self.context_window == 1:  
        # In window 1, only add window 1 messages as 'user'
        for attribute in self.windows[1]["text"]:
            if attribute.strip():  # Only add non-empty lines
                self.context.add_cogtext("user", attribute)
    else:
        # Default behaviour for window 0
        chosen_attributes = self.cognalities.get_attributes()
        for attribute in chosen_attributes:
            self.context.add_cogtext("system", attribute)
        for attribute in self.windows[1]["text"]:
            if attribute.strip(): 
                self.context.add_cogtext("system", attribute)

    # The rest of the method remains unchanged...
```

This change ensures that in window 1, window 1 messages are added as 'user', and window 0 messages aren't added at all. During window 0 focus, it follows the existing behaviour.

'''

