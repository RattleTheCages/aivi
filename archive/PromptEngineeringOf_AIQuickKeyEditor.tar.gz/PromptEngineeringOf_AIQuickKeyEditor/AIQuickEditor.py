

import os
import json
import argparse
import curses
from openai import OpenAI

client = OpenAI(api_key=os.environ.get("CUSTOM_ENV_NAME"))

parser = argparse.ArgumentParser()
parser.add_argument('--file', default='quick.txt')
args = parser.parse_args()

class CogQuery:
    def __init__(self, role, content):
        self.role = role
        self.content = content

class Cogtext:
    def __init__(self, model, max_tokens):
        self.model = model
        self.max_tokens = max_tokens
        self.cogessages = []
        self.usermsg = []

    def reset(self):
        self.cogessages = [msg for msg in self.cogessages if msg.role == 'system']
        self.usermsg = []

    def get_model(self):
        return self.model

    def get_maxtokens(self):
        return self.max_tokens

    def add_cogtext(self, role, content):
        self.cogessages.append(CogQuery(role, content))

    def get_cogtext(self):
        context = [{"role": message.role, "content": message.content} for message in self.cogessages]
        context += [{"role": "user", "content": umsg} for umsg in self.usermsg]
        return context

    def add_usermsg(self, msg):
        self.usermsg.append(msg)

    def save_cogtext(self, filename):
        with open(filename, 'w') as f:
            json.dump({"model": self.model, "max_tokens": self.max_tokens, "messages": self.get_cogtext()}, f)

    def load_cogtext(self, filename):
        if os.path.exists(filename):
            with open(filename, 'r') as f:
                data = json.load(f)
                self.model = data.get('model', '')
                self.max_tokens = data.get('max_tokens', 0)
                self.cogessages = [CogQuery(item['role'], item['content']) for item in data.get('messages', [])]

class Cognatlities:
    def __init__(self, name):
        self.name = name
        self.attributes = []

    def get_attributes(self):
        return self.attributes

    def add_attribute(self, attribute):
        self.attributes.append(attribute)

class AIQuickEditor:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.mode = "edit"
        self.status = ""
        self.line_num = 0
        self.linesInContext = 0
        self.text = [""]
        self.col_num = 0
        self.oldtext = []
        self.cognalities = {}


        cognatlity = Cognatlities('Telephone')
        cognatlity.add_attribute("This is the children's game of 'telephone', play nicely.")
        self.cognalities[cognatlity.name] = cognatlity

        cognatlity = Cognatlities('Spell and Grammer check')
        cognatlity.add_attribute('Your task is to spell and grammer check the following sentences. ')
        cognatlity.add_attribute('Take each sentence and output a corresponding corrected sentence. ')
        cognatlity.add_attribute('The user wants the answer strictly formatted as the quesiton. ')
        self.cognalities[cognatlity.name] = cognatlity

        cognatlity = Cognatlities('Python Coder')
        cognatlity.add_attribute('Your task is to code in python. ')
        cognatlity.add_attribute('You are the best programmer who will think of every task to complete. ')
        cognatlity.add_attribute('You are very competent and good at writing code. ')
        self.cognalities[cognatlity.name] = cognatlity

        self.personalchoice = "Python Coder"

       #self.context = Cogtext("gpt-3.5-turbo", 298)
        self.context = Cogtext("gpt-4o", 4096)
        chosen_attributes = self.cognalities[self.personalchoice].get_attributes()
        for attribute in chosen_attributes:
            self.context.add_cogtext("system", attribute)

    def handle_return(self):
        line = self.text[self.line_num]
        self.context.add_cogtext("user", line)
        self.context.add_usermsg(line)
        self.text.insert(self.line_num + 1, self.text[self.line_num][self.col_num:])
        self.text[self.line_num] = self.text[self.line_num][:self.col_num]

        self.line_num += 1
        self.col_num = 0
        self.linesInContext += 1

    def display(self):
        modeOrStatus = self.mode
        if self.status != "":
            modeOrStatus = self.status
            self.status = ""
        self.stdscr.clear()
        for y, line in enumerate(self.text):
            try:
                self.stdscr.addstr(y, 0, f"{y:03}<{modeOrStatus:5}>", curses.A_REVERSE | curses.A_BOLD if y == self.line_num else curses.A_REVERSE)
                if y == self.line_num:
                    for x, ch in enumerate(line):
                        if x == self.col_num:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  #Prevent crash due to writing outside of the window size
        self.stdscr.refresh()


    def insert_char(self, ch):
        self.mode = 'edit'
        line = self.text[self.line_num]
        if ch in (curses.KEY_BACKSPACE, 127):  # Backspace character
            if self.col_num > 0:
                self.text[self.line_num] = line[:self.col_num - 1] + line[self.col_num:]
                self.col_num -= 1
        else:
            self.text[self.line_num] = line[:self.col_num] + chr(ch) + line[self.col_num:]
            self.col_num += 1

    def handle_backspace(self, ch):
        if self.mode == "reply" or self.mode == 'undo':
            if self.mode == 'reply':
                self.mode = 'undo'
            else:
                self.mode = 'reply'

            self.oldertext = self.text
            self.text = self.oldtext
            self.oldtext = self.oldertext
        else:
            self.insert_char(ch)


    def handle_up_arrow(self):
        if self.line_num > 0:
            self.mode = "edit"
            self.line_num -= 1
            if self.col_num > len(self.text[self.line_num]):
                self.col_num = len(self.text[self.line_num])

    def handle_down_arrow(self):
        if self.line_num < len(self.text) - 1:
            self.mode = "edit"
            self.line_num += 1
            if self.col_num > len(self.text[self.line_num]):
                self.col_num = len(self.text[self.line_num])

    def handle_right_arrow(self):
        line = self.text[self.line_num]
        if self.col_num < len(line):
            self.mode = "edit"
            self.col_num += 1

    def handle_left_arrow(self):
        if self.col_num > 0:
            self.mode = "edit"
            self.col_num -= 1

    def handle_backslash(self):
        self.context.reset()
        userlines = "\n".join(self.text)
        self.context.add_usermsg(userlines)

        self.status = "ai   "
        self.display()
        completion = client.chat.completions.create(
            model=self.context.get_model(),
            max_tokens=self.context.get_maxtokens(),
            messages=self.context.get_cogtext()
        )
        self.context.add_cogtext("assistant", completion.choices[0].message.content)
        self.context.save_cogtext('context.json')

        self.oldtext = self.text
        self.text = completion.choices[0].message.content.split('\n')
        self.line_num = len(self.text) - 1
        self.linesInContext = self.line_num
        self.col_num = len(self.text[self.line_num])
        self.mode = "reply"

    def write_file(self):
        try:
            with open(args.file, 'w') as f:
                for line in self.text:
                    f.write(line + '\n')
            self.status = "wrote"
        except Exception as e:
            self.status = "no wr"

    def read_file(self):
        try:
            with open(args.file, 'r') as f:
                self.text = [line.rstrip('\n') for line in f]
            if not self.text:
                raise ValueError("File is empty")
            self.line_num = 0
            self.status = "read "
        except FileNotFoundError:
            self.status = "not f"
        except PermissionError:
            self.status = "denid"
        except IsADirectoryError:
            self.status = "dir  "
        except IOError:
            self.status = "IO er"
        except ValueError as err:
            self.status = "empty"

    def run(self):
        while True:
            self.display()
            ch = self.stdscr.getch()
            if ch == curses.KEY_UP:
                self.handle_up_arrow()
            elif ch == curses.KEY_DOWN:
                self.handle_down_arrow()
            elif ch == curses.KEY_RIGHT:
                self.handle_right_arrow()
            elif ch == curses.KEY_LEFT:
                self.handle_left_arrow()
            elif ch == ord('\\'):  # Backslash
                self.handle_backslash()
            elif ch == ord('\n'):  # Return
                self.handle_return()
            elif ch in (curses.KEY_BACKSPACE, 127):  # Backspace
                self.handle_backspace(ch)
            elif ch == 23:  # Ctrl-W
                self.write_file()
            elif ch == 18:  # Ctrl-R
                self.read_file()
            else:
                if self.line_num >= len(self.text):
                    self.text.append('')
                self.insert_char(ch)

def main(stdscr):
    editor = AIQuickEditor(stdscr)
    editor.run()

if __name__ == '__main__':
    curses.wrapper(main)





