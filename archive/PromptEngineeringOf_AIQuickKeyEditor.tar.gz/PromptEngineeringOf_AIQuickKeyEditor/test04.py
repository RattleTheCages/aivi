'''
To handle the cursor movement correctly and ensure separate file writes for each window, we'll make the following updates to the existing code:

1. Modify the `display` method to correctly position the cursor based on the `col_num` and `line_num` values for the respective window.
2. Update the `write_file` method to write the contents of the top and bottom windows into separate files with `_top` and `_bottom` suffixes.

### Updated Code:

```python
'''
import os
import json
import argparse
import curses
from openai import OpenAI

# Initialize OpenAI client
client = OpenAI(api_key=os.environ.get("CUSTOM_ENV_NAME"))

# Setup argument parser for file input
parser = argparse.ArgumentParser()
parser.add_argument('--file', default='quick.txt')
args = parser.parse_args()

class CogQuery:
    def __init__(self, role, content):
        self.role = role
        self.content = content

class Cogtext:
    def __init__(self, model, max_tokens):
        self.model = model
        self.max_tokens = max_tokens
        self.cogessages = []
        self.usermsg = []

    def reset(self):
        self.cogessages = [msg for msg in self.cogessages if msg.role == 'system']
        self.usermsg = []

    def get_model(self):
        return self.model

    def get_maxtokens(self):
        return self.max_tokens

    def add_cogtext(self, role, content):
        self.cogessages.append(CogQuery(role, content))

    def get_cogtext(self):
        context = [{"role": message.role, "content": message.content} for message in self.cogessages]
        context += [{"role": "user", "content": umsg} for umsg in self.usermsg]
        return context

    def add_usermsg(self, msg):
        self.usermsg.append(msg)

    def save_cogtext(self, filename):
        with open(filename, 'w') as f:
            json.dump({"model": self.model, "max_tokens": self.max_tokens, "messages": self.get_cogtext()}, f)

    def load_cogtext(self, filename):
        if os.path.exists(filename):
            with open(filename, 'r') as f:
                data = json.load(f)
                self.model = data.get('model', '')
                self.max_tokens = data.get('max_tokens', 0)
                self.cogessages = [CogQuery(item['role'], item['content']) for item in data.get('messages', [])]

class Cognatlities:
    def __init__(self, name):
        self.name = name
        self.attributes = []

    def get_attributes(self):
        return self.attributes

    def add_attribute(self, attribute):
        self.attributes.append(attribute)

class AIQuickEditor:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.mode = "edit"
        self.status = ""
        self.context_window = 0
        
        self.windows = [
            {"line_num": 0, "col_num": 0, "text": [""]},
            {"line_num": 0, "col_num": 0, "text": [""]},
        ]
        
        self.oldtext = []
        self.cognalities = {}

        cognatlity = Cognatlities('Python Coder')
        cognatlity.add_attribute('Correct the spelling add grammer of the input. ')
        self.cognalities[cognatlity.name] = cognatlity

        self.personalchoice = "Python Coder"

        self.context = Cogtext("gpt-4", 4096)
        chosen_attributes = self.cognalities[self.personalchoice].get_attributes()
        for attribute in chosen_attributes:
            self.context.add_cogtext("system", attribute)

        if args.file:
            self.read_file()

    def handle_return(self):
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        self.context.add_cogtext("user", line)
        self.context.add_usermsg(line)
        current_window["text"].insert(current_window["line_num"] + 1, current_window["text"][current_window["line_num"]][current_window["col_num"]:])
        current_window["text"][current_window["line_num"]] = current_window["text"][current_window["line_num"]][:current_window["col_num"]]

        current_window["line_num"] += 1
        current_window["col_num"] = 0

    def display(self):
        modeOrStatus = self.mode
        if self.status != "":
            modeOrStatus = self.status
            self.status = ""
        
        self.stdscr.clear()
        top_window = self.windows[0]["text"]
        bottom_window = self.windows[1]["text"]

        for y, line in enumerate(top_window):
            if y >= 38:
                break
            try:
                self.stdscr.addstr(y, 0, f"{y:03}<{modeOrStatus:5}>", curses.A_REVERSE | curses.A_BOLD if self.context_window == 0 and y == self.windows[0]["line_num"] else curses.A_REVERSE)
                if self.context_window == 0 and y == self.windows[0]["line_num"]:
                    for x, ch in enumerate(line):
                        if x == self.windows[0]["col_num"]:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                    # Ensure cursor is always visible
                    if self.context_window == 0:
                        self.stdscr.move(y, self.windows[0]["col_num"] + len(f"{y:03}<{modeOrStatus:5}>"))
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  # Prevent crash due to writing outside of the window size

        for y in range(38, 46):
            if y - 38 >= len(bottom_window):
                break
            line = bottom_window[y-38]
            try:
                self.stdscr.addstr(y, 0, f"{y:03}<{modeOrStatus:5}>", curses.A_REVERSE | curses.A_BOLD if self.context_window == 1 and y - 38 == self.windows[1]["line_num"] else curses.A_REVERSE)
                if self.context_window == 1 and y - 38 == self.windows[1]["line_num"]:
                    for x, ch in enumerate(line):
                        if x == self.windows[1]["col_num"]:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                    # Ensure cursor is always visible
                    if self.context_window == 1:
                        self.stdscr.move(y, self.windows[1]["col_num"] + len(f"{y:03}<{modeOrStatus:5}>"))
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  # Prevent crash due to writing outside of the window size

        self.stdscr.refresh()

    def insert_char(self, ch):
        self.mode = 'edit'
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        if ch in (curses.KEY_BACKSPACE, 127):  # Backspace character
            if current_window["col_num"] > 0:
                current_window["text"][current_window["line_num"]] = line[:current_window["col_num"] - 1] + line[current_window["col_num"]:]
                current_window["col_num"] -= 1
        else:
            current_window["text"][current_window["line_num"]] = line[:current_window["col_num"]] + chr(ch) + line[current_window["col_num"]:]
            current_window["col_num"] += 1

    def handle_backspace(self, ch):
        if self.mode == "reply" or self.mode == 'undo':
            if self.mode == 'reply':
                self.mode = 'undo'
            else:
                self.mode = 'reply'

            self.oldertext = self.windows[self.context_window]["text"]
            self.windows[self.context_window]["text"] = self.oldtext
            self.oldtext = self.oldertext
        else:
            self.insert_char(ch)

    def handle_up_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["line_num"] > 0:
            self.mode = "edit"
            current_window["line_num"] -= 1
            if current_window["col_num"] > len(current_window["text"][current_window["line_num"]]):
                current_window["col_num"] = len(current_window["text"][current_window["line_num"]])

    def handle_down_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["line_num"] < len(current_window["text"]) - 1:
            self.mode = "edit"
            current_window["line_num"] += 1
            if current_window["col_num"] > len(current_window["text"][current_window["line_num"]]):
                current_window["col_num"] = len(current_window["text"][current_window["line_num"]])

    def handle_right_arrow(self):
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        if current_window["col_num"] < len(line):
            self.mode = "edit"
            current_window["col_num"] += 1

    def handle_left_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["col_num"] > 0:
            self.mode = "edit"
            current_window["col_num"] -= 1

    def handle_backslash(self):
        self.context.reset()
        userlines = "\n".join(self.windows[self.context_window]["text"])
        self.context.add_usermsg(userlines)

        self.status = "ai"
        self.display()
        completion = client.chat.completions.create(
            model=self.context.get_model(),
            max_tokens=self.context.get_maxtokens(),
            messages=self.context.get_cogtext()
        )
        self.context.add_cogtext("assistant", completion.choices[0].message.content)
        self.context.save_cogtext('context.json')

        self.oldtext = self.windows[self.context_window]["text"]
        self.windows[self.context_window]["text"] = completion.choices[0].message.content.split('\n')
        self.windows[self.context_window]["line_num"] = len(self.windows[self.context_window]["text"]) - 1
        self.windows[self.context_window]["col_num"] = len(self.windows[self.context_window]["text"][self.windows[self.context_window]["line_num"]])
        self.mode = "reply"

    def write_file(self):
        try:
            file_base_name = os.path.splitext(args.file)[0]
            with open(file_base_name + '_top.txt', 'w') as f:
                for line in self.windows[0]["text"]:
                    f.write(line + '\n')

            with open(file_base_name + '_bottom.txt', 'w') as f:
                for line in self.windows[1]["text"]:
                    f.write(line + '\n')

            self.status = "wrote"
        except Exception as e:
            self.status = "no wr"

    def read_file(self):
        try:
            with open(args.file, 'r') as f:
                lines = [line.rstrip('\n') for line in f]
            if not lines:
                raise ValueError("File is empty")
            
            self.windows[0]["text"] = lines[:38] if len(lines) > 38 else lines
            self.windows[1]["text"] = lines[38:46] if len(lines) > 38 else [""]
            self.windows[0]["line_num"] = 0
            self.windows[1]["line_num"] = 0

            self.status = "read"
        except FileNotFoundError:
            self.status = "not f"
        except PermissionError:
            self.status = "denid"
        except IsADirectoryError:
            self.status = "dir  "
        except IOError:
            self.status = "IO er"
        except ValueError as err:
            self.status = "empty"

    def run(self):
        while True:
            self.display()
            ch = self.stdscr.getch()
            if ch == curses.KEY_UP:
                self.handle_up_arrow()
            elif ch == curses.KEY_DOWN:
                self.handle_down_arrow()
            elif ch == curses.KEY_RIGHT:
                self.handle_right_arrow()
            elif ch == curses.KEY_LEFT:
                self.handle_left_arrow()
            elif ch == ord('\\'):  # Backslash
                self.handle_backslash()
            elif ch == ord('\n'):  # Return
                self.handle_return()
            elif ch in (curses.KEY_BACKSPACE, 127):  # Backspace
                self.handle_backspace(ch)
            elif ch == 23:  # Ctrl-W
                self.write_file()
            elif ch == 18:  # Ctrl-R
                self.read_file()
            elif ch == 1:  # Ctrl-A
                self.context_window = 1 - self.context_window
            else:
                if self.windows[self.context_window]["line_num"] >= len(self.windows[self.context_window]["text"]):
                    self.windows[self.context_window]["text"].append('')
                self.insert_char(ch)

def main(stdscr):
    editor = AIQuickEditor(stdscr)
    editor.run()

if __name__ == '__main__':
    curses.wrapper(main)
'''

### Explanation:

1. **Cursor Movement in `display` Method:**
   - The cursor is now correctly positioned using `self.stdscr.move()` based on the `col_num` and `line_num` values for the respective window.

2. **File Write in `write_file` Method:**
   - The method is updated to write the contents of `top` and `bottom` windows into separate files suffixed with `_top` and `_bottom`.

With these changes, the cursor will follow the position correctly in the display method, and each window will write its content into separate files upon execution of the `Ctrl-W` (write file) command.

'''

