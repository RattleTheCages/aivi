This is the archive of the prompt programming that created some of AIQuickKeyEditor
