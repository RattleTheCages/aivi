
import os
import sys
import json
import argparse
import curses
from openai import OpenAI

parser = argparse.ArgumentParser()
parser.add_argument('--file', default='quick.txt')
args = parser.parse_args()
client = OpenAI(api_key=os.environ.get("CUSTOM_ENV_NAME"))

class CogQuery:
    def __init__(self, role, content):
        self.role = role
        self.content = content

class Cognatlities:
    def __init__(self):
        self.cognalities = {
            'Spell and Grammer check': [
                'Your task is to spell and grammer check the following sentences.',
                'Take each sentence and output a corresponding corrected sentence.',
                'The user wants the answer strictly formatted as the question.'
            ],

            'Freestyle': [],

            'Telephone': [
                "This is the children's game of 'telephone', play nicely."
            ],

            'Python Coder': [
                'Your task is to code in python.',
                'You are the best programmer who will think of every task to complete.',
                'You are very competent and good at writing code.',
                "If there are grammatical or spelling errors in the task, correct the task; do not comment on the corrections to the task.",
                "Only consider the corrected task when determining your answer.",
                "Write the corrected task in quotes, in your comments."
            ],

            'Pirate and Polly': [
                "Answer the questions as an ornery pirate named Redbeard.",
                "If there are grammatical or spelling errors, correct the question; do not comment on the corrections to the question.",
                "Only consider the corrected question when determining your answer.",
                "Scoff at the question, then add the corrected question in quotes.",
                "After the pirate refuses to answer, have a helpful verbose parrot named 'Polly' answer; but then say something like 'Polly wants a cracker' most of the time, but sometimes something else.",
                "Every so often have the pirate respond to the bird.",
                "Both the pirate place before thier responses with \"Redbeard:\" and \"Polly:\" respectively.",
                "Both the pirate and the parrot place \"Redbeard:\" and \"Polly:\" respectively before their responses."
            ]


        }
        self.names = list(self.cognalities.keys())
        self.current_index = 0

    def get_current_name(self):
        return self.names[self.current_index]

    def get_attributes(self):
        return self.cognalities[self.get_current_name()]

    def next_cognality(self):
        self.current_index = (self.current_index + 1) % len(self.names)
        return self.get_current_name()
    
    def get_attributes_by_name(self, name):
        return self.cognalities.get(name, [])

class Cogtext:
    def __init__(self, model, max_tokens, cognalities):
        self.model = model
        self.max_tokens = max_tokens
        self.cognalities = cognalities
        self.cogessages = []
        self.usermsg = []

    def reset(self):
        self.cogessages = []
        self.usermsg = []

    def get_model(self):
        return self.model

    def get_maxtokens(self):
        return self.max_tokens

    def add_cogtext(self, role, content):
        self.cogessages.append(CogQuery(role, content))
    
    def add_cogatt(self, name, role, content):
        if name in self.cognalities.cognalities:
            self.cogessages.append(CogQuery(role, content))

    def get_cogtext(self):
        context = [{"role": message.role, "content": message.content} for message in self.cogessages]
        context += [{"role": "user", "content": umsg} for umsg in self.usermsg]
        return context

    def get_cogtext_by_name(self, name):
        attributes = self.cognalities.get_attributes_by_name(name)
        context = [{"role": "system", "content": attribute} for attribute in attributes]
        context += [{"role": "user", "content": umsg} for umsg in self.usermsg]
        return context

    def add_usermsg(self, msg):
        self.usermsg.append(msg)

    def save_cogtext(self, filename):
        with open(filename, 'w') as f:
            json.dump({"model": self.model, "max_tokens": self.max_tokens, "messages": self.get_cogtext()}, f)

    def load_cogtext(self, filename):
        if os.path.exists(filename):
            with open(filename, 'r') as f:
                data = json.load(f)
                self.model = data.get('model', '')
                self.max_tokens = data.get('max_tokens', 0)
                self.cogessages = [CogQuery(item['role'], item['content']) for item in data.get('messages', [])]

class AIQuickKeyEditor:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.mode = "edit"
        self.status = ""
        self.oldtext = []
        self.context_window = 0
        self.windows = [
            {"line_num": 0, "col_num": 0, "text": [""]},
            {"line_num": 0, "col_num": 0, "text": [""]},
        ]

        self.cognalities = Cognatlities()
        self.personalchoice = self.cognalities.get_current_name()
        self.context = Cogtext("gpt-3.5-turbo", 298, self.cognalities)
        

        if args.file:
            self.read_file()

    def handle_return(self):
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        self.context.add_cogtext("user", line)
        self.context.add_usermsg(line)
        current_window["text"].insert(current_window["line_num"] + 1, current_window["text"][current_window["line_num"]][current_window["col_num"]:])
        current_window["text"][current_window["line_num"]] = current_window["text"][current_window["line_num"]][:current_window["col_num"]]

        current_window["line_num"] += 1
        current_window["col_num"] = 0

    def display(self):
        modeOrStatus = self.mode
        if self.status != "":
            modeOrStatus = self.status
            self.status = ""

        self.stdscr.clear()
        top_window = self.windows[0]["text"]
        bottom_window = self.windows[1]["text"]

        for y, line in enumerate(top_window):
            if y >= 38:
                break
            try:
                self.stdscr.addstr(y, 0, f"{y:03}<{modeOrStatus:5}>", curses.A_REVERSE | curses.A_BOLD if self.context_window == 0 and y == self.windows[0]["line_num"] else curses.A_REVERSE)
                if self.context_window == 0 and y == self.windows[0]["line_num"]:
                    for x, ch in enumerate(line):
                        if x == self.windows[0]["col_num"]:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                    if self.context_window == 0:
                        self.stdscr.move(y, self.windows[0]["col_num"] + len(f"{y:03}<{modeOrStatus:5}>"))
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  # Prevent crash due to writing outside of the window size

        for y in range(38, 46):
            if y - 38 >= len(bottom_window):
                break
            line = bottom_window[y-38]
            try:
                self.stdscr.addstr(y, 0, f"{y:03}<{self.personalchoice:5}>", curses.A_REVERSE | curses.A_BOLD if self.context_window == 1 and y - 38 == self.windows[1]["line_num"] else curses.A_REVERSE)
                if self.context_window == 1 and y - 38 == self.windows[1]["line_num"]:
                    for x, ch in enumerate(line):
                        if x == self.windows[1]["col_num"]:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                    if self.context_window == 1:
                        self.stdscr.move(y, self.windows[1]["col_num"] + len(f"{y:03}<{modeOrStatus:5}>"))
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  # Prevent crash due to writing outside of the window size

        self.stdscr.refresh()

    def insert_char(self, ch):
        self.mode = 'edit'
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        if ch in (curses.KEY_BACKSPACE, 127):  # Backspace character
            if current_window["col_num"] > 0:
                current_window["text"][current_window["line_num"]] = line[:current_window["col_num"] - 1] + line[current_window["col_num"]:]
                current_window["col_num"] -= 1
        else:
            current_window["text"][current_window["line_num"]] = line[:current_window["col_num"]] + chr(ch) + line[current_window["col_num"]:]
            current_window["col_num"] += 1

    def handle_backspace(self, ch):
        if self.mode == "reply" or self.mode == 'undo':
            if self.mode == 'reply':
                self.mode = 'undo'
            else:
                self.mode = 'reply'

            self.oldertext = self.windows[0]["text"]
            self.windows[0]["text"] = self.oldtext
            self.oldtext = self.oldertext
        else:
            self.insert_char(ch)

    def handle_up_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["line_num"] > 0:
            self.mode = "edit"
            current_window["line_num"] -= 1
            if current_window["col_num"] > len(current_window["text"][current_window["line_num"]]):
                current_window["col_num"] = len(current_window["text"][current_window["line_num"]])

    def handle_down_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["line_num"] < len(current_window["text"]) - 1:
            self.mode = "edit"
            current_window["line_num"] += 1
            if current_window["col_num"] > len(current_window["text"][current_window["line_num"]]):
                current_window["col_num"] = len(current_window["text"][current_window["line_num"]])

    def handle_right_arrow(self):
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        if current_window["col_num"] < len(line):
            self.mode = "edit"
            current_window["col_num"] += 1

    def handle_left_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["col_num"] > 0:
            self.mode = "edit"
            current_window["col_num"] -= 1

    def handle_backslash(self):  # Backslash ('\')
      # Light green is my favorite color, but the sky is a wonderful hue of blue.
        self.context.reset()

        chosen_attributes = self.cognalities.get_attributes()
        for attribute in chosen_attributes:
            self.context.add_cogtext("system", attribute)

        for attribute in self.windows[1]["text"]:
            if attribute.strip():    #Only add non-empty lines
                self.context.add_cogtext("system", attribute)

        for attribute in self.windows[0]["text"]:
            if attribute.strip():    #Only add non-empty lines
                self.context.add_cogtext("user", attribute)

        self.context.save_cogtext('before_context.json')
        self.status = "ai   "
        self.display()

        # Debug, write the context before the AI reply.
        #sys.stdout.write(json.dumps(self.context.get_cogtext(), indent=2))

        completion = client.chat.completions.create(
            model=self.context.get_model(),
            max_tokens=self.context.get_maxtokens(),
            messages=self.context.get_cogtext()
        )
        self.context.add_cogtext("assistant", completion.choices[0].message.content)
        self.context.save_cogtext('ai_context.json')

        self.oldtext = self.windows[0]["text"]
        self.windows[0]["text"] = completion.choices[0].message.content.split('\n')
        self.windows[0]["line_num"] = len(self.windows[0]["text"]) - 1
        self.windows[0]["col_num"] = len(self.windows[0]["text"][self.windows[0]["line_num"]])
        self.mode = "reply"

    def write_file(self):
        try:
            file_base_name = os.path.splitext(args.file)[0]
            with open(file_base_name + '.txt', 'w') as f:
                for line in self.windows[0]["text"]:
                    f.write(line + '\n')

            with open(file_base_name + '.ctx', 'w') as f:
                for line in self.windows[1]["text"]:
                    f.write(line + '\n')

            self.status = "wrote"
        except Exception as e:
            self.status = "no wr"

    def read_file(self):
        try:
            with open(args.file, 'r') as f:
                lines = [line.rstrip('\n') for line in f]
            if not lines:
                raise ValueError("File is empty")

            self.windows[0]["text"] = lines[:38] if len(lines) > 38 else lines
            self.windows[1]["text"] = lines[38:46] if len(lines) > 38 else [""]
            self.windows[0]["line_num"] = 0
            self.windows[1]["line_num"] = 0

            self.status = "read"
        except FileNotFoundError:
            self.status = "not f"
        except PermissionError:
            self.status = "denid"
        except IsADirectoryError:
            self.status = "dir  "
        except IOError:
            self.status = "IO er"
        except ValueError as err:
            self.status = "empty"

    def handle_ctrl_p(self):
        self.personalchoice = self.cognalities.next_cognality()
        self.context.reset()
        self.context.get_cogtext_by_name(self.personalchoice)

    def run(self):
        while True:
            self.display()
            ch = self.stdscr.getch()
            if ch == curses.KEY_UP:
                self.handle_up_arrow()
            elif ch == curses.KEY_DOWN:
                self.handle_down_arrow()
            elif ch == curses.KEY_RIGHT:
                self.handle_right_arrow()
            elif ch == curses.KEY_LEFT:
                self.handle_left_arrow()
            elif ch == ord('\\'):  # Backslash
                self.handle_backslash()
            elif ch == ord('\n'):  # Return
                self.handle_return()
            elif ch in (curses.KEY_BACKSPACE, 127):  # Backspace
                self.handle_backspace(ch)
            elif ch == 23:  # Ctrl-W
                self.write_file()
            elif ch == 18:  # Ctrl-R
                self.read_file()
            elif ch == 1:  # Ctrl-A
                self.context_window = 1 - self.context_window
            elif ch == 16:  # Ctrl-P
                self.handle_ctrl_p()
            else:
                if self.windows[self.context_window]["line_num"] >= len(self.windows[self.context_window]["text"]):
                    self.windows[self.context_window]["text"].append('')
                self.insert_char(ch)

def main(stdscr):
    editor = AIQuickKeyEditor(stdscr)
    editor.run()

if __name__ == '__main__':
    curses.wrapper(main)

