
import os
import json
import argparse
import curses
from openai import OpenAI

parser = argparse.ArgumentParser()
parser.add_argument('file', nargs='?', default=None)
args = parser.parse_args()
client = OpenAI(api_key=os.environ.get("CUSTOM_ENV_NAME"))

class CogQuery:
    @classmethod
    def get_unique_request_counter(cls, file_base_name):
        while os.path.exists(f'{file_base_name}_{cls.request_counter}.txt'):
            cls.update_request_counter()
        return cls.request_counter
    request_counter = 0
    def __init__(self, role, content):
        self.role = role
        self.content = content
    @classmethod
    def update_request_counter(cls):
        cls.request_counter += 1
        return cls.request_counter

class Cognalities:
    def __init__(self):
        self.cognalities = {
            'Spell & Grammar': {
                'attributes': [
                    'Your task is to spell and grammar check the following sentences.',
                    'Take each sentence and output a corresponding corrected sentence.',
                    'The user wants the answer strictly formatted as the question.'
                ],
                'model': 'gpt-3.5-turbo',
                'max_tokens': 298
            },
            'Python Coder': {
                'attributes': [
                    'Your task is to code in python.',
                    'You are the best programmer who will think of every task to complete.',
                    'You are very competent and good at writing code.',
                    'Truncate unmodified functions or classes: Include only the functions or classes that have been changed. Do not include entire files or unmodified parts.',
                    'Include sufficient context: Ensure that the snippets have enough context for understanding the changes.',
                    'Provide modifications explicitly: Clearly mark what has been added, updated, or removed in the code.'
                ],
                'model': 'gpt-4o',
                'max_tokens': 4096
            },
            'Freestyle': {
                'attributes': [],
                'model': 'gpt-4o',
                'max_tokens': 4096
            },
            'Telephone': {
                'attributes': [
                    "This is the children's game of 'telephone', play nicely."
                ],
                'model': 'gpt-4',
                'max_tokens': 898
            }
        }
        self.names = list(self.cognalities.keys())
        self.current_index = 0
    def get_current_name(self):
        return self.names[self.current_index]
    def get_attributes(self):
        return self.cognalities[self.get_current_name()]['attributes']
    def next_cognality(self):
        self.current_index = (self.current_index + 1) % len(self.names)
        return self.get_current_name()
    def get_attributes_by_name(self, name):
        return self.cognalities.get(name, {}).get('attributes', [])
    def get_model(self):
        return self.cognalities[self.get_current_name()]['model']
    def get_maxtokens(self):
        return self.cognalities[self.get_current_name()]['max_tokens']

class Cogtext:
    def __init__(self, cognalities):
        self.cognalities = cognalities
        self.cogessages = []
        self.usermsg = []
    def reset(self):
        self.cogessages = []
        self.usermsg = []
    def add_cogtext(self, role, content):
        self.cogessages.append(CogQuery(role, content))
    def add_cogatt(self, name, role, content):
        if name in self.cognalities.cognalities:
            self.cogessages.append(CogQuery(role, content))
    def get_cogtext(self):
        context = [{"role": message.role, "content": message.content} for message in self.cogessages]
        context += [{"role": "user", "content": umsg} for umsg in self.usermsg]
        return context
    def get_cogtext_by_name(self, name):
        attributes = self.cognalities.get_attributes_by_name(name)
        context = [{"role": "system", "content": attribute} for attribute in attributes]
        context += [{"role": "user", "content": umsg} for umsg in self.usermsg]
        return context
    def add_usermsg(self, msg):
        self.usermsg.append(msg)
    def save_cogtext(self, filename):
        with open(filename, 'w') as f:
            json.dump({
                "model": self.cognalities.get_model(),
                "max_tokens": self.cognalities.get_maxtokens(),
                "messages": self.get_cogtext()
            }, f)
    def load_cogtext(self, filename):
        if os.path.exists(filename):
            with open(filename, 'r') as f:
                data = json.load(f)
                self.cognalities.model = data.get('model', '')
                self.cognalities.max_tokens = data.get('max_tokens', 0)
                self.cogessages = [CogQuery(item['role'], item['content']) for item in data.get('messages', [])]

class AIQuickKeyEditor:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.mode = "edit"
        self.status = ""
        self.oldtext = {}
        self.context_window = 0
        self.search_results = []
        self.current_search_result = -1
        self.windows = [
            {"line_num": 0, "col_num": 0, "text": [""]},
            {"line_num": 0, "col_num": 0, "text": [""]},
        ]
        self.window_offsets = [0, 0]
        self.cognalities = Cognalities()
        self.personalchoice = self.cognalities.get_current_name()
        self.context = Cogtext(self.cognalities)
        if args.file:
            self.read_file()
        else:
            self.show_splash_screen()

    def handle_return(self):
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        self.context.add_cogtext("user", line)
        self.context.add_usermsg(line)
        current_window["text"].insert(current_window["line_num"] + 1, current_window["text"][current_window["line_num"]][current_window["col_num"]:])
        current_window["text"][current_window["line_num"]] = current_window["text"][current_window["line_num"]][:current_window["col_num"]]
        current_window["line_num"] += 1
        current_window["col_num"] = 0
        self.adjust_window_offset()
    def display(self):
        modeOrStatus = self.mode
        if self.status != "":
            modeOrStatus = self.status
            self.status = ""
        self.stdscr.clear()
        top_window = self.windows[0]["text"]
        bottom_window = self.windows[1]["text"]
        for y in range(min(38, len(top_window) - self.window_offsets[0])):
            line = top_window[y + self.window_offsets[0]]
            try:
                self.stdscr.addstr(y, 0, f"{y + self.window_offsets[0]:03}<{modeOrStatus:5}>", curses.A_REVERSE | curses.A_BOLD if self.context_window == 0 and y + self.window_offsets[0] == self.windows[0]["line_num"] else curses.A_REVERSE)
                if self.context_window == 0 and y + self.window_offsets[0] == self.windows[0]["line_num"]:
                    for x, ch in enumerate(line):
                        if x == self.windows[0]["col_num"]:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                    if self.context_window == 0:
                        self.stdscr.move(y, self.windows[0]["col_num"] + len(f"{y + self.window_offsets[0]:03}<{modeOrStatus:5}>"))
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  # Prevent crash due to writing outside of the window size
        # Bottom window
        for y in range(38, 46):
            if y - 38 >= len(bottom_window) - self.window_offsets[1]:
                break
            line = bottom_window[y - 38 + self.window_offsets[1]]
            try:
                self.stdscr.addstr(y, 0, f"{y - 38 + self.window_offsets[1]:03}<{self.personalchoice:5}>", curses.A_REVERSE | curses.A_BOLD if self.context_window == 1 and y - 38 + self.window_offsets[1] == self.windows[1]["line_num"] else curses.A_REVERSE)
                if self.context_window == 1 and y - 38 + self.window_offsets[1] == self.windows[1]["line_num"]:
                    for x, ch in enumerate(line):
                        if x == self.windows[1]["col_num"]:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                    if self.context_window == 1:
                        self.stdscr.move(y, self.windows[1]["col_num"] + len(f"{y - 38 + self.window_offsets[1]:03}<{self.personalchoice:5}>"))
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  # Prevent crash due to writing outside of the window size
        self.stdscr.refresh()
    def adjust_window_offset(self):
        for i in range(2):
            while self.windows[i]["line_num"] < self.window_offsets[i]:
                self.window_offsets[i] -= 1
            while self.windows[i]["line_num"] >= self.window_offsets[i] + (38 if i == 0 else 8):
                self.window_offsets[i] += 1
    def insert_char(self, ch):
        self.mode = 'edit'
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        if ch in (curses.KEY_BACKSPACE, 127):  # Backspace character
            if current_window["col_num"] > 0:
                current_window["text"][current_window["line_num"]] = line[:current_window["col_num"] - 1] + line[current_window["col_num"]:]
                current_window["col_num"] -= 1
            elif current_window["col_num"] == 0 and current_window["line_num"] > 0:
                prev_line = current_window["text"][current_window["line_num"] - 1]
                current_window["col_num"] = len(prev_line)
                current_window["text"][current_window["line_num"] - 1] += current_window["text"].pop(current_window["line_num"])
                current_window["line_num"] -= 1
        else:
            current_window["text"][current_window["line_num"]] = line[:current_window["col_num"]] + chr(ch) + line[current_window["col_num"]:]
            current_window["col_num"] += 1
        self.adjust_window_offset()
    def handle_backspace(self, ch):
        if self.mode == "reply" or self.mode == 'undo':
            if self.mode == 'reply':
                self.mode = 'undo'
            else:
                self.mode = 'reply'
            # Store the text of the current window separately
            if self.context_window not in self.oldtext:
                self.oldtext[self.context_window] = []
            self.oldertext = self.windows[self.context_window]["text"]
            self.windows[self.context_window]["text"] = self.oldtext[self.context_window]
            self.oldtext[self.context_window] = self.oldertext
        else:
            self.insert_char(ch)
    def handle_up_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["line_num"] > 0:
            self.mode = "edit"
            current_window["line_num"] -= 1
            if current_window["col_num"] > len(current_window["text"][current_window["line_num"]]):
                current_window["col_num"] = len(current_window["text"][current_window["line_num"]])
            self.adjust_window_offset()
    def handle_down_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["line_num"] < len(current_window["text"]) - 1:
            self.mode = "edit"
            current_window["line_num"] += 1
            if current_window["col_num"] > len(current_window["text"][current_window["line_num"]]):
                current_window["col_num"] = len(current_window["text"][current_window["line_num"]])
            self.adjust_window_offset()
    def handle_right_arrow(self):
        current_window = self.windows[self.context_window]
        line = current_window["text"][current_window["line_num"]]
        if current_window["col_num"] < len(line):
            self.mode = "edit"
            current_window["col_num"] += 1
    def handle_left_arrow(self):
        current_window = self.windows[self.context_window]
        if current_window["col_num"] > 0:
            self.mode = "edit"
            current_window["col_num"] -= 1
    def handle_backslash(self):
        file_base_name = os.path.splitext(args.file)[0]
        request_id = CogQuery.get_unique_request_counter(file_base_name)
        before_context_filename = f'{file_base_name}_before_context_{request_id}.json'
        ai_context_filename = f'{file_base_name}_ai_context_{request_id}.json'
        self.context.reset()
        chosen_attributes = self.cognalities.get_attributes()
        for attribute in chosen_attributes:
            self.context.add_cogtext("system", attribute)
        if self.context_window == 1:
            userlines = ""
            for line in self.windows[1]["text"]:
                if line.strip():
                    userlines += line + '\n'
            self.context.add_cogtext("user", userlines)
        else:
            userlines = ""
            for line in self.windows[1]["text"]:
                if line.strip():
                    userlines += line + '\n'
            self.context.add_cogtext("system", userlines)
            userlines = ""
            for line in self.windows[0]["text"]:
                if line.strip():
                    userlines += line + '\n'
            self.context.add_cogtext("user", userlines)
        self.context.save_cogtext(before_context_filename)
        self.write_file()
        # I am a fluffy unicorn, with light green spots.
        self.status = "ai   "
        self.display()
        completion = client.chat.completions.create(
            model=self.cognalities.get_model(),
            max_tokens=self.cognalities.get_maxtokens(),
            messages=self.context.get_cogtext()
        )
        self.context.add_cogtext("assistant", completion.choices[0].message.content)
        self.context.save_cogtext(ai_context_filename)

        if self.context_window not in self.oldtext:
            self.oldtext[self.context_window] = []
        self.oldtext[self.context_window] = self.windows[self.context_window]["text"]
        self.windows[self.context_window]["text"] = completion.choices[0].message.content.split('\n')
        self.windows[self.context_window]["line_num"] = len(self.windows[self.context_window]["text"]) - 1
        self.windows[self.context_window]["col_num"] = len(self.windows[self.context_window]["text"][self.windows[self.context_window]["line_num"]])
        self.mode = 'reply'
        self.adjust_window_offset()
    def write_file(self):
        try:
            file_base_name = os.path.splitext(args.file)[0]
            request_id = CogQuery.get_unique_request_counter(file_base_name)
            with open(f'{file_base_name}_{request_id}.txt', 'w') as f:
                for line in self.windows[0]["text"]:
                    f.write(line + '\n')
            with open(f'{file_base_name}_{request_id}.ctx', 'w') as f:
                for line in self.windows[1]["text"]:
                    f.write(line + '\n')
            self.status = "wrote"
        except Exception as e:
            self.status = "no wr"
    def read_file(self):
        try:
            with open(args.file, 'r') as f:
                lines = [line.rstrip('\n') for line in f]
            if not lines:
                raise ValueError("File is empty")
            self.windows[0]["text"] = lines
            self.windows[1]["text"] = [""]
            self.windows[0]["line_num"] = 0
            self.windows[0]["col_num"] = 0
            self.windows[1]["line_num"] = 0
            self.windows[1]["col_num"] = 0
            self.status = "read "
            self.adjust_window_offset()
        except FileNotFoundError:
            self.status = "not f"
        except PermissionError:
            self.status = "denid"
        except IsADirectoryError:
            self.status = "dir  "
        except IOError:
            self.status = "IO er"
        except ValueError as err:
            self.status = "empty"
    def handle_ctrl_p(self):
        self.personalchoice = self.cognalities.next_cognality()
        self.context.reset()
        self.context.get_cogtext_by_name(self.personalchoice)
        self.adjust_window_offset()

    def search_text(self):
        search_term = "\n".join(self.windows[1]["text"]).strip()
        if not search_term:
            self.status = "no tm"
            return
        
        self.search_results.clear()
        top_window = self.windows[0]["text"]
        for i, line in enumerate(top_window):
            start_idx = 0
            while start_idx < len(line):
                start_idx = line.find(search_term, start_idx)
                if start_idx == -1:
                    break
                self.search_results.append((i, start_idx))
                start_idx += len(search_term)

        if self.search_results:
            self.current_search_result = 0
            self.highlight_search_result()
            self.status = f"found {len(self.search_results)}"
        else:
            self.status = "not f"

    def highlight_search_result(self):
        if not self.search_results:
            return
        
        line_num, col_num = self.search_results[self.current_search_result]
        self.windows[0]["line_num"] = line_num
        self.windows[0]["col_num"] = col_num
        self.adjust_window_offset()

    def next_search_result(self):
        if self.search_results:
            self.current_search_result = (self.current_search_result + 1) % len(self.search_results)
            self.highlight_search_result()

    def prev_search_result(self):
        if self.search_results:
            self.current_search_result = (self.current_search_result - 1) % len(self.search_results)
            self.highlight_search_result()

    def run(self):
        while True:
            self.display()
            ch = self.stdscr.getch()
            if ch == curses.KEY_UP:
                self.handle_up_arrow()
            elif ch == curses.KEY_DOWN:
                self.handle_down_arrow()
            elif ch == curses.KEY_RIGHT:
                self.handle_right_arrow()
            elif ch == curses.KEY_LEFT:
                self.handle_left_arrow()
            elif ch == ord('\\'):
                self.handle_backslash()
            elif ch == ord('\n'):
                self.handle_return()
            elif ch in (curses.KEY_BACKSPACE, 127):
                self.handle_backspace(ch)
            elif ch == 23:
                self.write_file()
            elif ch == 18:
                self.read_file()
            elif ch == 1:
                self.context_window = 1 - self.context_window
            elif ch == 16:
                self.handle_ctrl_p()
            elif ch == 6:  # Ctrl-F
                self.search_text()
            elif ch == 14:  # Ctrl-N
                self.next_search_result()
            elif ch == 2:  # Ctrl-B
                self.prev_search_result()
            else:
                if self.windows[self.context_window]["line_num"] >= len(self.windows[self.context_window]["text"]):
                    self.windows[self.context_window]["text"].append('')
                self.insert_char(ch)

    def show_splash_screen(self):
        self.stdscr.clear()
        self.mode = 'splsh'
        splash_text = [
            "Welcome to the AIQuickKeyEditor!",
            "",
            "Control Characters:",
            "Ctrl-A: Switch between editor window and AI command",
            "Ctrl-W: Write the editor window to a file",
            "Ctrl-R: Read the file to edit",
            "Ctrl-P: Switch AI Personality Eg Spell and Grammer check, Python Coder",
            "Backslash (\\): Send editor window to AI and recive reply",
            "Backspace (<-): Switch between the AI reply and the original, for quick comapeirson",
            "Use the arrow keys to navigate and start typing to edit.",
            "",
            "Enjoy your AI-Assisted text and code writing experience!"
        ]
        splash_text_width = max(len(line) for line in splash_text) + 1
        splash_text_height = len(splash_text)
        screen_height, screen_width = self.stdscr.getmaxyx()
        for y, line in enumerate(splash_text):
            if y >= splash_text_height:
                break
            x = ((screen_width - splash_text_width) // 2) -2
            self.stdscr.addstr(y, x, line)
            self.stdscr.addstr(y, 0, f"{y + 1:03}<{self.mode:5}>", curses.A_REVERSE)
        self.stdscr.refresh()
        self.stdscr.getch()

def main(stdscr):
    editor = AIQuickKeyEditor(stdscr)
    editor.run()

if __name__ == "__main__":
    curses.wrapper(main)


To implement the feature that cycles through 10 undos, labeling them as `undo0`, `undo1`, ..., `undo9` in mode, you need to update the `AIQuickKeyEditor` class specifically the `handle_backspace` and `display` methods. Here's the modified code to achieve this:

```python
class AIQuickKeyEditor:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.mode = "edit"
        self.status = ""
        self.undo_index = 0  # Added to keep track of the current undo level
        self.oldtext = {i: {} for i in range(10)}  # Store up to 10 undo states
        self.context_window = 0
        self.search_results = []
        self.current_search_result = -1
        self.windows = [
            {"line_num": 0, "col_num": 0, "text": [""]},
            {"line_num": 0, "col_num": 0, "text": [""]},
        ]
        self.window_offsets = [0, 0]
        self.cognalities = Cognalities()
        self.personalchoice = self.cognalities.get_current_name()
        self.context = Cogtext(self.cognalities)
        if args.file:
            self.read_file()
        else:
            self.show_splash_screen()

    def handle_backspace(self, ch):
        if self.mode == "edit" or self.mode.startswith('undo'):
            self.mode = f'undo{self.undo_index}'
            # Store the text of the current window separately
            if self.context_window not in self.oldtext[self.undo_index]:
                self.oldtext[self.undo_index][self.context_window] = []
            self.oldertext = self.windows[self.context_window]["text"]
            self.windows[self.context_window]["text"] = self.oldtext[self.undo_index].get(self.context_window, [])
            self.oldtext[self.undo_index][self.context_window] = self.oldertext
            self.undo_index = (self.undo_index + 1) % 10  # Cycle through 0-9

    def display(self):
        modeOrStatus = self.mode
        if self.status != "":
            modeOrStatus = self.status
            self.status = ""
        self.stdscr.clear()
        top_window = self.windows[0]["text"]
        bottom_window = self.windows[1]["text"]

        for y in range(min(38, len(top_window) - self.window_offsets[0])):
            line = top_window[y + self.window_offsets[0]]
            try:
                self.stdscr.addstr(y, 0, f"{y + self.window_offsets[0]:03}<{modeOrStatus:5}>",
                                   curses.A_REVERSE | curses.A_BOLD if self.context_window == 0 and y + self.window_offsets[0] == self.windows[0]["line_num"] else curses.A_REVERSE)
                if self.context_window == 0 and y + self.window_offsets[0] == self.windows[0]["line_num"]:
                    for x, ch in enumerate(line):
                        if x == self.windows[0]["col_num"]:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                    if self.context_window == 0:
                        self.stdscr.move(y, self.windows[0]["col_num"] + len(f"{y + self.window_offsets[0]:03}<{modeOrStatus:5}>"))
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  # Prevent crash due to writing outside of the window size

        # Bottom window
        for y in range(38, 46):
            if y - 38 >= len(bottom_window) - self.window_offsets[1]:
                break
            line = bottom_window[y - 38 + self.window_offsets[1]]
            try:
                self.stdscr.addstr(y, 0, f"{y - 38 + self.window_offsets[1]:03}<{self.personalchoice:5}>",
                                   curses.A_REVERSE | curses.A_BOLD if self.context_window == 1 and y - 38 + self.window_offsets[1] == self.windows[1]["line_num"] else curses.A_REVERSE)
                if self.context_window == 1 and y - 38 + self.window_offsets[1] == self.windows[1]["line_num"]:
                    for x, ch in enumerate(line):
                        if x == self.windows[1]["col_num"]:
                            self.stdscr.addch(ch, curses.A_REVERSE)
                        else:
                            self.stdscr.addch(ch)
                    if self.context_window == 1:
                        self.stdscr.move(y, self.windows[1]["col_num"] + len(f"{y - 38 + self.window_offsets[1]:03}<{self.personalchoice:5}>"))
                else:
                    self.stdscr.addstr(line)
            except curses.error:
                pass  # Prevent crash due to writing outside of the window size

        self.stdscr.refresh()

    # Rest of the class remains unchanged.
```

### Key Changes:
1. **`self.undo_index`**: Added to keep track of the current undo level.
2. **`self.oldtext`**: Adjusted to store up to 10 undo states using a dictionary with range(10) for keys.
3. **`handle_backspace`**:
   - Updated to cycle through undo states from `undo0` to `undo9`.
   - Adjusted the undo logic to handle 10 states cycling.
4. **`display`**:
   - Updated to display the current undo state in the mode label, showing `undo0` to `undo9` as appropriate.

By adding these changes, the editor will now cycle through 10 undo states, making it easier for users to revert back to previous versions step by step.
