


import random
import time

class Goldfish:
    def __init__(self, name):
        self.name = name
        self.position = [0, 0]
        
    def move(self, bowl_size):
        direction = random.choice(['up', 'down', 'left', 'right'])
        if direction == 'up' and self.position[1] < bowl_size - 1:
            self.position[1] += 1
        elif direction == 'down' and self.position[1] > 0:
            self.position[1] -= 1
        elif direction == 'left' and self.position[0] > 0:
            self.position[0] -= 1
        elif direction == 'right' and self.position[0] < bowl_size - 1:
            self.position[0] += 1
            
    def __str__(self):
        return f'{self.name} is at position {self.position}'

class FishBowl:
    def __init__(self, size):
        self.size = size
        self.goldie = Goldfish('Goldie')  # Renamed to 'Goldie'
        self.boyfriend = Goldfish('Boyfriend')
        
    def draw_bowl(self):
        bowl = [['.' for _ in range(self.size)] for _ in range(self.size)]
        goldie_x, goldie_y = self.goldie.position
        bowl[goldie_y][goldie_x] = 'G'  # Represent Goldie with 'G'
        boyfriend_x, boyfriend_y = self.boyfriend.position
        # Ensure only one fish is in the cell
        if bowl[boyfriend_y][boyfriend_x] == '.':
            bowl[boyfriend_y][boyfriend_x] = 'F'  # Represent Boyfriend with 'F'
        top_bottom_border = '+' + '-' * self.size + '+'
        print(top_bottom_border)
        for row in bowl:
            print('|' + ''.join(row) + '|')
        print(top_bottom_border)
        
    def simulate(self, steps):
        for _ in range(steps):
            self.goldie.move(self.size)
            self.boyfriend.move(self.size)
            self.draw_bowl()
            print(self.goldie)
            print(self.boyfriend)
            time.sleep(1)

if __name__ == "__main__":
    bowl = FishBowl(size=7)  # Increase the size of the bowl
    bowl.simulate(steps=10)


