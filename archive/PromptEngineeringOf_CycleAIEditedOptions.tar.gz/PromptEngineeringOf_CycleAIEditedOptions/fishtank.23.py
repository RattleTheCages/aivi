


import random
import time

class Goldfish:
    def __init__(self, name):
        self.name = name
        self.position = [0, 0]
        self.mad_turns = 0

    def move(self, bowl_size):
        direction = random.choice(['up', 'down', 'left', 'right'])
        if direction == 'up' and self.position[1] < bowl_size - 1:
            self.position[1] += 1
        elif direction == 'down' and self.position[1] > 0:
            self.position[1] -= 1
        elif direction == 'left' and self.position[0] > 0:
            self.position[0] -= 1
        elif direction == 'right' and self.position[0] < bowl_size - 1:
            self.position[0] += 1

    def __str__(self):
        display_name = self.name[::-1] if self.mad_turns > 0 else self.name
        return f'{display_name} is at position {self.position}'

class FishBowl:
    def __init__(self, size):
        self.size = size
        self.goldie = Goldfish('Goldie')
        self.claude = Goldfish('Claude')
        self.bubbles = Goldfish('Bubbles')

    def draw_bowl(self):
        bowl = [['.' for _ in range(self.size)] for _ in range(self.size)]
        goldie_x, goldie_y = self.goldie.position
        bowl[goldie_y][goldie_x] = 'G'
        claude_x, claude_y = self.claude.position
        if bowl[claude_y][claude_x] == '.':
            bowl[claude_y][claude_x] = 'C'
        bubbles_x, bubbles_y = self.bubbles.position
        if bowl[bubbles_y][bubbles_x] == '.':
            bowl[bubbles_y][bubbles_x] = 'B'
        top_bottom_border = '+' + '-' * self.size + '+'
        print(top_bottom_border)
        for row in bowl:
            print('|' + ''.join(row) + '|')
        print(top_bottom_border)

    def check_proximity(self):
        if self.bubbles.position == self.claude.position:
            self.goldie.mad_turns = 4
        elif self.goldie.mad_turns > 0:
            self.goldie.mad_turns -= 1

    def simulate(self, steps):
        for _ in range(steps):
            self.goldie.move(self.size)
            self.claude.move(self.size)
            self.bubbles.move(self.size)
            self.check_proximity()
            self.draw_bowl()
            print(self.goldie)
            print(self.claude)
            print(self.bubbles)
            time.sleep(1)

if __name__ == "__main__":
    bowl = FishBowl(size=10)  # Increase the size of the bowl
    bowl.simulate(steps=10)



