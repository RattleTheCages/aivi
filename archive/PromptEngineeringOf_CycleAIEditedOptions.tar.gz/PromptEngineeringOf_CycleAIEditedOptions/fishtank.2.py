


import random
import time

class FishBowl:
    def __init__(self, size=10):
        self.size = size
        self.goldfish = Goldfish(self.size)

    def display_bowl(self):
        bowl = [" "] * self.size
        bowl[self.goldfish.position] = "F"
        print("FishBowl: [" + "".join(bowl) + "]")

    def run_simulation(self, steps=10, interval=1):
        for _ in range(steps):
            self.goldfish.move()
            self.display_bowl()
            time.sleep(interval)


class Goldfish:
    def __init__(self, bowl_size):
        self.bowl_size = bowl_size
        self.position = random.randint(0, bowl_size - 1)

    def move(self):
        # Goldfish can move left (-1) or right (+1)
        move_direction = random.choice([-1, 1])
        self.position += move_direction
        # Make sure goldfish stays within the bowl
        self.position = max(0, min(self.position, self.bowl_size - 1))


if __name__ == "__main__":
    fish_bowl = FishBowl(size=20)
    fish_bowl.run_simulation(steps=20, interval=0.5)



