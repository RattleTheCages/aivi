


import random
import time

class FishBowl:
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def is_within_bounds(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    def display(self, fish):
        for y in range(self.height):
            for x in range(self.width):
                if (x, y) == (fish.x, fish.y):
                    print("><((('>", end='')
                else:
                    print("~", end='')
            print()
        print()

class Goldfish:
    def __init__(self, name, fishbowl):
        self.name = name
        self.fishbowl = fishbowl
        self.x = random.randint(0, fishbowl.width - 1)
        self.y = random.randint(0, fishbowl.height - 1)
    
    def swim(self):
        dx, dy = random.choice([(-1, 0), (1, 0), (0, -1), (0, 1)])
        new_x = self.x + dx
        new_y = self.y + dy

        if self.fishbowl.is_within_bounds(new_x, new_y):
            self.x = new_x
            self.y = new_y

def simulate_fish_bowl(fishbowl, fish, steps):
    for _ in range(steps):
        fish.swim()
        fishbowl.display(fish)
        time.sleep(0.5)

if __name__ == "__main__":
    width, height = 10, 5
    fishbowl = FishBowl(width, height)
    goldfish = Goldfish("Goldie", fishbowl)    
    steps = 20
    simulate_fish_bowl(fishbowl, goldfish, steps)


