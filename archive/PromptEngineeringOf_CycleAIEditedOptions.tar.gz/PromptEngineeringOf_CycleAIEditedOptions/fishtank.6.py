



import random
import math

class Goldfish:
    def __init__(self, name):
        self.name = name
        self.position = [0.0, 0.0]  # Assuming a 2D plane for simplicity

    def swim(self):
        # Move the goldfish to a new position within the bowl
        angle = random.uniform(0, 2 * math.pi)
        distance = random.uniform(0, 1)
        self.position[0] += distance * math.cos(angle)
        self.position[1] += distance * math.sin(angle)

    def __repr__(self):
        return f"{self.name} is at position {self.position}"

class FishBowl:
    def __init__(self, radius):
        self.radius = radius
        self.goldfish = None

    def add_goldfish(self, goldfish):
        self.goldfish = goldfish

    def is_within_bowl(self, position):
        return math.sqrt(position[0]**2 + position[1]**2) <= self.radius

    def update(self):
        if self.goldfish:
            original_position = self.goldfish.position[:]
            self.goldfish.swim()
            if not self.is_within_bowl(self.goldfish.position):
                self.goldfish.position = original_position

    def __repr__(self):
        return f"FishBowl with radius {self.radius} containing: {self.goldfish}"

# Let's simulate our fishbowl and goldfish
bowl = FishBowl(radius=5.0)
goldie = Goldfish(name="Goldie")
bowl.add_goldfish(goldie)

for _ in range(10):  # simulate 10 time steps
    bowl.update()
    print(bowl)




