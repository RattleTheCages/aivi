

import random
import time

class Goldfish:
    def __init__(self, name):
        self.name = name
        self.position = [0, 0]

    def move(self, bowl_size):
        direction = random.choice(['up', 'down', 'left', 'right'])
        if direction == 'up' and self.position[1] < bowl_size - 1:
            self.position[1] += 1
        elif direction == 'down' and self.position[1] > 0:
            self.position[1] -= 1
        elif direction == 'left' and self.position[0] > 0:
            self.position[0] -= 1
        elif direction == 'right' and self.position[0] < bowl_size - 1:
            self.position[0] += 1

    def __str__(self):
        return f'{self.name} is at position {self.position}'

class FishBowl:
    def __init__(self, size):
        self.size = size
        self.goldfish = Goldfish('Goldie')

    def draw_bowl(self):
        bowl = [['.' for _ in range(self.size)] for _ in range(self.size)]
        fish_x, fish_y = self.goldfish.position
        bowl[fish_y][fish_x] = 'F'  # Represent the fish with 'F'
        top_bottom_border = '+' + '-' * self.size + '+'
        print(top_bottom_border)
        for row in bowl:
            print('|' + ''.join(row) + '|')
        print(top_bottom_border)

    def simulate(self, steps):
        for _ in range(steps):
            self.goldfish.move(self.size)
            self.draw_bowl()
            print(self.goldfish)
            time.sleep(1)

if __name__ == "__main__":
    bowl = FishBowl(size=5)
    bowl.simulate(steps=10)




