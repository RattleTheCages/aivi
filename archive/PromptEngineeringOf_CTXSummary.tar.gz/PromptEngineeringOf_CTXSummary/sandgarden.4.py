
import random
import time
import os

class SandGarden:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.grid = [[' ' for _ in range(width)] for _ in range(height)]

    def add_sand(self, x, y):
        if self.is_in_bounds(x, y):
            self.grid[y][x] = 'S'

    def is_in_bounds(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    def step(self):
        new_grid = [[' ' for _ in range(self.width)] for _ in range(self.height)]
        for y in range(self.height - 1, -1, -1):
            for x in range(self.width):
                if self.grid[y][x] == 'S':
                    if self.is_in_bounds(x, y + 1) and self.grid[y + 1][x] == ' ':
                        new_grid[y + 1][x] = 'S'
                    else:
                        new_grid[y][x] = 'S'
        self.grid = new_grid

    def display(self):
        os.system('clear' if os.name == 'posix' else 'cls')
        for row in self.grid:
            print(''.join(row))
        print()

def main():
    width, height = 20, 10
    garden = SandGarden(width, height)
    for _ in range(30):
        x = random.randint(0, width - 1)
        garden.add_sand(x, 0)

    while True:
        garden.display()
        garden.step()
        time.sleep(0.1)

if __name__ == "__main__":
    main()
