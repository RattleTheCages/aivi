

import random

class Fishbowl:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.bowl = [[' ' for _ in range(width)] for _ in range(height)]

    def add_fish(self, fish, count):
        for _ in range(count):
            x = random.randint(1, self.width - 2)
            y = random.randint(1, self.height - 2)
            self.bowl[y][x] = fish

    def display(self):
        top_bottom_border = "+" + "-" * (self.width - 2) + "+"
        print(top_bottom_border)
        for row in self.bowl:
            print("|", end='')
            for cell in row:
                print(cell, end='')
            print("|")
        print(top_bottom_border)

def main():
    width = 20
    height = 10
    fishbowl = Fishbowl(width, height)

    fishbowl.add_fish('><>', 5)
    fishbowl.add_fish('><(((*>', 2)

    fishbowl.display()

if __name__ == "__main__":
    main()

