import random

class Goldfish:
    def __init__(self, name):
        self.name = name
        self.hunger = 0
        self.energy = 100

    def swim(self):
        if self.energy > 0:
            print(f"{self.name} is swimming around the bowl.")
            self.energy -= 10
            self.hunger += 5
        else:
            print(f"{self.name} is too tired to swim.")
        
    def eat(self):
        if self.hunger > 0:
            print(f"{self.name} is eating some fish flakes.")
            self.hunger -= 10
            self.energy += 20
        else:
            print(f"{self.name} is not hungry.")

    def sleep(self):
        print(f"{self.name} is resting at the bottom of the bowl.")
        self.energy += 30
        self.hunger += 5
        
    def status(self):
        print(f"{self.name} has {self.energy} energy and {self.hunger} hunger.")

class Bowl:
    def __init__(self):
        self.fish = []

    def add_fish(self, fish):
        if isinstance(fish, Goldfish):
            self.fish.append(fish)
            print(f"{fish.name} has been added to the bowl.")
        else:
            print("You can only add goldfish to the bowl.")

    def feed_fish(self):
        for fish in self.fish:
            fish.eat()

    def let_fish_swim(self):
        for fish in self.fish:
            fish.swim()

    def let_fish_sleep(self):
        for fish in self.fish:
            fish.sleep()

    def get_status(self):
        for fish in self.fish:
            fish.status()

# Example Usage:
my_bowl = Bowl()
goldie = Goldfish("Goldie")
bubbles = Goldfish("Bubbles")

my_bowl.add_fish(goldie)
my_bowl.add_fish(bubbles)

my_bowl.feed_fish()
my_bowl.let_fish_swim()
my_bowl.get_status()
my_bowl.let_fish_sleep()
my_bowl.get_status()



