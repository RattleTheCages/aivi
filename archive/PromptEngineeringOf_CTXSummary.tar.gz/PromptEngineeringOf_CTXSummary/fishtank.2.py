

import random

class Fish:
    def __init__(self, name, tank_width, tank_height):
        self.name = name
        self.tank_width = tank_width
        self.tank_height = tank_height
        self.x = random.randint(0, tank_width - 1)
        self.y = random.randint(0, tank_height - 1)

    def move(self):
        move_x = random.choice([-1, 0, 1])
        move_y = random.choice([-1, 0, 1])
        self.x = (self.x + move_x) % self.tank_width
        self.y = (self.y + move_y) % self.tank_height

    def __str__(self):
        return "{0} at ({1}, {2})".format(self.name, self.x, self.y)

class Tank:
    def __init__(self, width, height, num_fish):
        self.width = width
        self.height = height
        self.fish = [Fish(f"Fish{i+1}", width, height) for i in range(num_fish)]

    def simulate(self, steps):
        for _ in range(steps):
            self.tick()
            print(self)

    def tick(self):
        for fish in self.fish:
            fish.move()

    def __str__(self):
        tank_representation = [[" " for _ in range(self.width)] for _ in range(self.height)]
        for fish in self.fish:
            tank_representation[fish.y][fish.x] = "F"
        return "\n".join(["".join(row) for row in tank_representation])


if __name__ == "__main__":
    tank = Tank(10, 10, 3)
    tank.simulate(10)




