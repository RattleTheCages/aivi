


import os
import random
import time
import threading

class Fishbowl:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.bowl = [[' ' for _ in range(width)] for _ in range(height)]
        self.fish_positions = []  # Track positions of the fish
        self.boat_position = (0, '__|\_')
        self.move_direction = 1
        self.hook_position = (len(self.boat_position[1]) // 2 + 1, 1)  # Initial hook position

    def add_fish(self, fish, count):
        for _ in range(count):
            x = random.randint(1, self.width - 2)
            y = random.randint(1, self.height - 2)
            self.bowl[y][x] = fish
            self.fish_positions.append((x, y, fish))

    def move_fish(self):
        directions = ['up', 'down', 'left', 'right']
        new_positions = []
        for (x, y, fish) in self.fish_positions:
            self.bowl[y][x:x+len(fish)] = [' '] * len(fish)  # Clear current position
            direction = random.choice(directions)
            if direction == 'up' and y > 1:
                y -= 1
            elif direction == 'down' and y < self.height - 2:
                y += 1
            elif direction == 'left' and x > 1:
                x -= 1
            elif direction == 'right' and x < self.width - 1 - len(fish):
                x += 1
            new_positions.append((x, y, fish))
            self.bowl[y][x:x+len(fish)] = list(fish)  # Update new position
        self.fish_positions = new_positions

    def move_boat(self):
        boat, graphic = self.boat_position
        new_boat = boat + self.move_direction
        if new_boat < 0 or new_boat + len(graphic) > self.width:
            self.move_direction *= -1
        new_boat += self.move_direction

        self.boat_position = (new_boat, graphic)
        self.hook_position = (new_boat + len(graphic) // 2, 1)

    def display(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        top_bottom_border = "+" + "-" * (self.width - 2) + "+"
        boat, graphic = self.boat_position

        print(top_bottom_border)
        print("|" + " " * boat + graphic.ljust(self.width - 2 - boat) + "|")

        # Create a "fishing line"
        for i in range(1, self.hook_position[1]):
            line_row = [' '] * self.width
            line_row[boat + len(graphic) // 2] = '|'
            print("|" + ''.join(line_row[1:-1]) + "|")

        for row in self.bowl:
            print("|", end='')
            for cell in row:
                print(cell, end='')
            print("|")
        
        print(top_bottom_border)

def continuously_move_fish(fishbowl):
    while True:
        fishbowl.move_fish()
        fishbowl.move_boat()
        fishbowl.display()
        time.sleep(0.25)  # Move fish and boat every 1/4 sec

def main():
    width = 88
    height = 40
    fishbowl = Fishbowl(width, height)
    fishbowl.add_fish('><>', 5)
    fishbowl.add_fish('><(((*>', 2)
    fishbowl.display()

    # Start a separate thread to move fish and boat continuously
    movement_thread = threading.Thread(target=continuously_move_fish, args=(fishbowl,))
    movement_thread.daemon = True  # Daemonize thread to exit when main program exits
    movement_thread.start()

    try:
        while True:
            time.sleep(1)  # Keep main thread alive
    except KeyboardInterrupt:
        print("Exiting...")

if __name__ == "__main__":
    main()




