

import os
import random
import time
import threading

class Fishbowl:
    def __init__(self, width, height):
            self.width = width
            self.height = height
            self.bowl = [[' ' for _ in range(width)] for _ in range(height)]
            self.fish_positions = []  # Track positions of the fish
    
    
    def add_fish(self, fish, count):
            for _ in range(count):
                x = random.randint(1, self.width - 2)
                y = random.randint(1, self.height - 2)
                self.bowl[y][x] = fish
                self.fish_positions.append((x, y, fish))
        
    
    def move_fish(self):
            directions = ['up', 'down', 'left', 'right']
            new_positions = []
            for (x, y, fish) in self.fish_positions:
                self.bowl[y][x:x+len(fish)] = [' '] * len(fish)  # Clear current position
                direction = random.choice(directions)
                if direction == 'up' and y > 1:
                    y -= 1
                elif direction == 'down' and y < self.height - 2:
                    y += 1
                elif direction == 'left' and x > 1:
                    x -= 1
                elif direction == 'right' and x < self.width - 1 - len(fish):
                    x += 1
                new_positions.append((x, y, fish))
                self.bowl[y][x:x+len(fish)] = list(fish)  # Update new position
            self.fish_positions = new_positions
    
    
    def display(self):
            top_bottom_border = "+" + "-" * (self.width - 2) + "+"
            fishing_boat = "   __|\_"
            boat_length = len(fishing_boat)
    
            print(top_bottom_border)
            # Print the boat
            print("|" + fishing_boat.ljust(self.width - 2) + "|")
    
            for row in self.bowl:
                print("|", end='')
                for cell in row:
                    print(cell, end='')
                print("|")
            print(top_bottom_border)
    
    
def continuously_move_fish(fishbowl):
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        fishbowl.move_fish()
        fishbowl.display()
        time.sleep(0.25)  # Move fish every 1/4 sec


def main():
    width = 88
    height = 40
    fishbowl = Fishbowl(width, height)
    fishbowl.add_fish('><>', 5)
    fishbowl.add_fish('><(((*>', 2)
    fishbowl.display()

    # Start a separate thread to move fish continuously
    movement_thread = threading.Thread(target=continuously_move_fish, args=(fishbowl,))
    movement_thread.daemon = True  # Daemonize thread to exit when main program exits
    movement_thread.start()

    try:
        while True:
            time.sleep(1)  # Keep main thread alive
    except KeyboardInterrupt:
        print("Exiting...")

if __name__ == "__main__":
    main()

