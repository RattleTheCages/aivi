

import random
import time

class Cat:
    def __init__(self, name, max_jump_distance=3, sleep_time=5):
        self.name = name
        self.position = 0
        self.max_jump_distance = max_jump_distance
        self.sleep_time = sleep_time
        self.energy = 100  # Start with full energy

    def walk(self, steps):
        """Move the cat by a certain number of steps."""
        self.position += steps
        self.energy -= steps
        print(f"{self.name} walked {steps} steps to position {self.position}.")

    def jump(self):
        """Make the cat jump a random distance up to its max_jump_distance."""
        if self.energy <= 0:
            print(f"{self.name} is too tired to jump!")
            return
        jump_distance = random.randint(1, self.max_jump_distance)
        self.position += jump_distance
        self.energy -= jump_distance * 2  # Jumping is more energy consuming
        print(f"{self.name} jumped {jump_distance} steps to position {self.position}.")

    def sleep(self):
        """Make the cat sleep to regain energy."""
        print(f"{self.name} is sleeping.")
        time.sleep(self.sleep_time)
        self.energy = 100  # Restore full energy
        print(f"{self.name} woke up refreshed with full energy.")

    def simulate_hot_tin_roof(self, seconds, hotness):
        """
        Simulate the cat on a hot tin roof for a certain number of seconds.
        The hotter the tin, the more frequently the cat will move.
        """
        start_time = time.time()
        while time.time() - start_time < seconds:
            if hotness > 5 and self.energy > 0:
                # Higher hotness means more activity
                if random.random() < 0.5:
                    self.jump()
                else:
                    self.walk(random.randint(1, self.max_jump_distance))
            else:
                self.sleep()

            time.sleep(1)  # Wait a bit before the next action


# Example of how to use the Cat class to simulate
if __name__ == "__main__":
    whiskers = Cat(name="Whiskers")
    whiskers.simulate_hot_tin_roof(seconds=30, hotness=7)




