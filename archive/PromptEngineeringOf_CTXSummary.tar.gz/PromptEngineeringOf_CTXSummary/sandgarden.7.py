



import random
import time
import os

# Base Class for Plant
class Plant:
    def __init__(self, symbol):
        self.symbol = symbol

# Derived Classes for Specific Plants
class Flower(Plant):
    def __init__(self):
        super().__init__('F')

class Tree(Plant):
    def __init__(self):
        super().__init__('T')

class Grass(Plant):
    def __init__(self):
        super().__init__('G')

# Derived Class for Phylum (Category/Group of Plants)
class Phylum:
    def __init__(self, name):
        self.name = name
        self.plants = []

    def add_plant(self, plant):
        self.plants.append(plant)

# Garden Class for Plant Simulation
class Garden:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.grid = [[' ' for _ in range(width)] for _ in range(height)]
        self.irrigation = [[False for _ in range(width)] for _ in range(height)]

    def add_plant(self, x, y, symbol):
        if self.is_in_bounds(x, y):
            self.grid[y][x] = symbol

    def is_in_bounds(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    def irrigate(self, x, y):
        if self.is_in_bounds(x, y):
            self.irrigation[y][x] = True

    def step(self):
        for y in range(self.height):
            for x in range(self.width):
                if self.irrigation[y][x] and self.grid[y][x] == ' ':
                    plant = self.random_plant()
                    self.grid[y][x] = plant.symbol

    def random_plant(self):
        # Randomly select a plant type to grow
        return random.choice([Flower(), Tree(), Grass()])

    def display(self):
        os.system('clear' if os.name == 'posix' else 'cls')
        for row in self.grid:
            print(''.join(row))
        print()

def main():
    width, height = 20, 10
    garden = Garden(width, height)

    # Initial Irrigation
    for _ in range(30):
        x = random.randint(0, width - 1)
        y = random.randint(0, height - 1)
        garden.irrigate(x, y)

    # Simulation loop
    while True:
        garden.display()
        garden.step()
        time.sleep(0.1)

if __name__ == "__main__":
    main()





