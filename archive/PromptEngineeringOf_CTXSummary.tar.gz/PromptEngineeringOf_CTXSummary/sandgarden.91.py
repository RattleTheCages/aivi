
class SandGarden:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.grid = [['.' for _ in range(width)] for _ in range(height)]  # Initial untouched sand represented by '.'

    def display_garden(self):
        for row in self.grid:
            print(' '.join(row))
        print()

    def rake(self, start_x, start_y, end_x, end_y, pattern='|'):
        """
        Rakes the sand garden from (start_x, start_y) to (end_x, end_y) creating a line pattern
        """
        if start_x == end_x:  # Vertical line
            for y in range(start_y, end_y + 1):
                if 0 <= y < self.height:
                    self.grid[y][start_x] = pattern
        elif start_y == end_y:  # Horizontal line
            for x in range(start_x, end_x + 1):
                if 0 <= x < self.width:
                    self.grid[start_y][x] = pattern
        else:
            print("Currently only vertical and horizontal lines are supported.")

    def rake_pattern(self, pattern_type='vertical_lines'):
        if pattern_type == 'vertical_lines':
            for x in range(0, self.width, 2):
                self.rake(x, 0, x, self.height - 1)
        elif pattern_type == 'horizontal_lines':
            for y in range(0, self.height, 2):
                self.rake(0, y, self.width - 1, y)
        elif pattern_type == 'crosshatch':
            self.rake_pattern('vertical_lines')
            self.rake_pattern('horizontal_lines')
        else:
            print(f"Pattern type '{pattern_type}' is not supported.")

# Example usage
if __name__ == "__main__":
    garden = SandGarden(20, 10)
    garden.display_garden()
    garden.rake_pattern('vertical_lines')
    garden.display_garden()
    garden.rake_pattern('horizontal_lines')
    garden.display_garden()
    garden.rake_pattern('crosshatch')
    garden.display_garden()




