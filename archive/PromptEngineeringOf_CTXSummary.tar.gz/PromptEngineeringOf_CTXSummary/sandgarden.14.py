



import random
import time
import os

# Base Class for Plant
class Plant:
    def __init__(self, symbol):
        self.symbol = symbol
        self.grown = False

    def grow(self):
        if not self.grown:
            self.symbol = self.symbol.upper()
            self.grown = True
        else:
            self.split()

    def split(self):
        pass  # This will be handled in the garden space management

# Derived Classes for Specific Plants
class Flower(Plant):
    def __init__(self):
        super().__init__('f')

class Tree(Plant):
    def __init__(self):
        super().__init__('t')

class Grass(Plant):
    def __init__(self):
        super().__init__('g')

# Garden Class for Plant Simulation
class Garden:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.grid = [[None for _ in range(width)] for _ in range(height)]
        self.irrigation = [[False for _ in range(width)] for _ in range(height)]

    def add_plant(self, x, y, plant):
        if self.is_in_bounds(x, y) and self.grid[y][x] is None:
            self.grid[y][x] = plant

    def is_in_bounds(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    def irrigate(self, x, y):
        if self.is_in_bounds(x, y):
            self.irrigation[y][x] = True

    def step(self):
        new_plants = []
        for y in range(self.height):
            for x in range(self.width):
                if self.irrigation[y][x] and self.grid[y][x] is not None:
                    plant = self.grid[y][x]
                    plant.grow()
                    if plant.grown:
                        self.grid[y][x] = plant
                        adjacent_positions = self.get_adjacent_positions(x, y)
                        random.shuffle(adjacent_positions)
                        for new_x, new_y in adjacent_positions:
                            if self.grid[new_y][new_x] is None:
                                new_plants.append((new_x, new_y, type(plant)()))
                                break
        for x, y, new_plant in new_plants:
            self.grid[y][x] = new_plant

    def get_adjacent_positions(self, x, y):
        # Get adjacent positions (N, S, E, W)
        positions = []
        if self.is_in_bounds(x, y - 1):
            positions.append((x, y - 1))
        if self.is_in_bounds(x, y + 1):
            positions.append((x, y + 1))
        if self.is_in_bounds(x - 1, y):
            positions.append((x - 1, y))
        if self.is_in_bounds(x + 1, y):
            positions.append((x + 1, y))
        return positions

    def random_plant(self):
        # Randomly select a plant type to grow
        return random.choice([Flower(), Tree(), Grass()])

    def display(self):
        os.system('clear' if os.name == 'posix' else 'cls')
        for row in self.grid:
            print(''.join([plant.symbol if plant else ' ' for plant in row]))
        print()

def main():
    width, height = 20, 10
    garden = Garden(width, height)
    
    # Add initial plants randomly in the garden
    for _ in range(5):
        x = random.randint(0, width - 1)
        y = random.randint(0, height - 1)
        plant = garden.random_plant()
        garden.add_plant(x, y, plant)

    # Initial Irrigation
    for _ in range(30):
        x = random.randint(0, width - 1)
        y = random.randint(0, height - 1)
        garden.irrigate(x, y)

    # Simulation loop
    while True:
        garden.display()
        garden.step()
        time.sleep(0.5)
        if all(cell is not None for row in garden.grid for cell in row):
            break

if __name__ == "__main__":
    main()



