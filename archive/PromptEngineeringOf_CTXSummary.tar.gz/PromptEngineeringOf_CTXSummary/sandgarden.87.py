

import random

class SandGarden:
    def __init__(self, width, height, stone_count=5):
        self.width = width
        self.height = height
        self.grid = [[' ' for _ in range(width)] for _ in range(height)]
        self.stone_count = stone_count
        self.place_stones()
        self.rake = SandRake(self)
    
    def place_stones(self):
        count = 0
        while count < self.stone_count:
            x, y = random.randint(0, self.width - 1), random.randint(0, self.height - 1)
            if self.grid[y][x] == ' ':
                self.grid[y][x] = 'O'
                count += 1
    
    def display(self):
        for row in self.grid:
            print(''.join(row))
        print()
    
    def rake_garden(self, start_x, start_y, direction):
        self.rake.rake_sand(start_x, start_y, direction)

class SandRake:
    def __init__(self, garden):
        self.garden = garden

    def rake_sand(self, start_x, start_y, direction):
        x, y = start_x, start_y
        dx, dy = 0, 0
        
        if direction == 'right':
            dx = 1
        elif direction == 'left':
            dx = -1
        elif direction == 'up':
            dy = -1
        elif direction == 'down':
            dy = 1
        
        while 0 <= x < self.garden.width and 0 <= y < self.garden.height:
            if self.garden.grid[y][x] == 'O':
                break
            self.garden.grid[y][x] = '-' if direction in ['right', 'left'] else '|'
            x += dx
            y += dy

if __name__ == '__main__':
    garden = SandGarden(width=15, height=10, stone_count=10)
    garden.display()
    garden.rake_garden(1, 1, 'right')
    garden.rake_garden(3, 3, 'down')
    garden.display()



