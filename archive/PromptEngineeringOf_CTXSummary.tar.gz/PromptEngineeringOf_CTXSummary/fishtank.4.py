

import random
import time
import os

class Fish:
    def __init__(self, name, x, y, dx, dy):
        self.name = name
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy
    
    def move(self, width, height):
        self.x += self.dx
        self.y += self.dy
        
        if self.x <= 0 or self.x >= width - 1:
            self.dx = -self.dx
        if self.y <= 0 or self.y >= height - 1:
            self.dy = -self.dy


class FishTank:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.fish = []

    def add_fish(self, fish):
        self.fish.append(fish)

    def update(self):
        for fish in self.fish:
            fish.move(self.width, self.height)
    
    def display(self):
        tank = [[' ' for _ in range(self.width)] for _ in range(self.height)]
        
        for fish in self.fish:
            tank[fish.y][fish.x] = 'F'
        
        tank_string = ''
        for row in tank:
            tank_string += ''.join(row) + '\n'
        
        os.system('clear' if os.name == 'posix' else 'cls')
        print(tank_string)


if __name__ == "__main__":
    width, height = 20, 10
    tank = FishTank(width, height)
    
    fish1 = Fish("Goldfish", random.randint(0, width-1), random.randint(0, height-1), 1, 1)
    fish2 = Fish("Betta", random.randint(0, width-1), random.randint(0, height-1), -1, -1)
    
    tank.add_fish(fish1)
    tank.add_fish(fish2)
    
    while True:
        tank.update()
        tank.display()
        time.sleep(1)



